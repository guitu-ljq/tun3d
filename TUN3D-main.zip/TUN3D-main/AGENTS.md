# TUN3D 项目导航

## 项目概览
- **TUN3D** 面向室内场景理解任务，支持输入带位姿/无位姿的多视角图像，分为 *reconstruction*（由 DUSt3R/CROCO 重建点云）与 *recognition*（基于 mmdetection3d 的 3D 目标检测与布局识别）两个模块。
- 根目录下仅包含必要的数据、模型源代码与说明文档，模块互相解耦，便于分别安装依赖或替换子组件。

## 顶层目录速览
| 路径 | 作用 | 关键内容 |
| --- | --- | --- |
| `README.md` | 顶层介绍、新闻、引用信息 | 列出模块划分、数据预处理与可视化示例。 |
| `recognition/` | 3D 检测 & 布局识别 | mmdetection3d 环境、`configs/`、`tools/train.py`、`tun3d/` 模型代码、`work_dirs/` 输出。 |
| `reconstruction/` | 图像到点云重建流水线 | 依赖 DUSt3R/CROCO，含 `infer.py`、`reconstruct.py`、`convert_to_bin.py` 等脚本。 |
| `data/` | 数据与预处理结果占位目录 | `scannet/`、`s3dis/`、`structured3d/` 子目录存放下载或生成的数据。 |
| `LICENSE` | 代码授权 | 采用 MIT。 |

## Reconstruction 模块
- 入口 README：`reconstruction/README.md`，详细列出数据目录结构、依赖安装以及 ScanNet/S3DIS 的 posed/unposed 全流程命令。
- 核心脚本
  - `infer.py`：调用 DUSt3R 生成稠密匹配，可指定数据集、图像路径、是否 posed 以及采样图像数量。
  - `reconstruct.py`：将 DUSt3R 输出转换成 `.ply`，支持置信度截断、对 unposed 模式执行姿态对齐。
  - `convert_to_bin.py`：将 `.ply` 点云转 `.bin`，为 recognition 模块提供输入。
  - `build_pkl.py`：针对 S3DIS 生成过滤后的样本索引。
- 重要子目录
  - `croco/`：包含官方 CROCO 代码、模型、demo，与立体匹配相关的 `models/*.py`、`stereoflow/` 等。
  - `dust3r/`：封装 DUSt3R 推理与训练逻辑，含 `model.py`、`heads/`、`losses.py`、`viz.py` 等。
  - `scannet_splits/`：预定义的训练/验证划分 txt。

## Recognition 模块
- README：`recognition/README.md`，复用 Unidet3D 环境并指向 mmdetection3d 官方文档；提供训练/测试/可视化命令以及各模态的公开模型与指标。
- 目录结构
  - `configs/`：所有实验配置（ScanNet/S3DIS、posed/unposed/Structured3D），命名遵循 `tun3d_*`。
  - `tools/train.py` & `tools/test.py`：直接复用 mmdetection3d 的 CLI；在仓库根目录执行。
  - `tun3d/`：项目特有组件，含自定义损失（`axis_aligned_iou_loss.py` 等）、数据集封装（`scannet_dataset.py`、`stru3d_dataset.py`）、网络结构（`mink_resnet.py`、`tun3d_head.py`、`tun3d_neck.py`）、变换与可视化工具。
  - `imgs/`：预测示例图。
  - `work_dirs/`：默认的训练输出目录（日志、检查点）。

## 数据目录
- `data/scannet/`、`data/s3dis/`、`data/structured3d/` 仅提供占位符，需按照各自子目录内 README/脚本或在顶层 README 中的 Hugging Face 链接下载。
- Reconstruction 流水线默认为以下输出：
  - `../data/<dataset>/posed_images/`：原始 RGB/深度/位姿文件。
  - `../data/<dataset>/points_{posed|unposed}`：DUSt3R 转换后的点云二进制文件。
  - S3DIS 还需在 `../data/s3dis/` 下生成 `s3dis_layout_infos_Area_*.pkl`。

## 典型工作流
1. **数据准备**：依据 `data/<dataset>/` 指引完成原始数据下载与整理；可直接拉取作者在 Hugging Face 提供的预处理结果。
2. **重建阶段（可选）**：
   - 在 `reconstruction/` 中运行 `python infer.py ...` → `python reconstruct.py ...` → `python convert_to_bin.py ...`。
   - S3DIS 需要额外执行 `build_pkl.py` 过滤缺失重建的场景。
3. **识别阶段**：
   - 进入 `recognition/`，使用 `python tools/train.py configs/tun3d_*.py` 训练；`work_dirs/` 会保存日志和模型。
   - 用 `python tools/test.py ... --show --show-dir ...` 进行评估与可视化。

## 扩展与协作提示
- Reconstruction 与 Recognition 互相独立，若只需替换重建算法，可在生成同名 `.bin`/`.pkl` 文件的前提下直接接入 recognition。
- 自定义实验配置可复制 `recognition/configs/` 中的现有文件并调整数据源、损失或模型深度；`tun3d/` 模块已经提供常见的损失、数据加载和后处理工具。
- 推荐在各模块目录下分别创建虚拟环境，以免交叉依赖冲突；可参考 recognition README 中的 Docker 链接或 reconstruction README 的 DUSt3R 指南。

