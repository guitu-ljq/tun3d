# GeoConf Stage-1 Freeze

Date: 2026-04-24

## Freeze Decision

- Stage-1 module: `GeoConf-TUN3D`
- Stage-1 role: `uncertainty-aware reconstruction feature`
- Mechanism validated: suppress `unposed reconstruction noise propagation`
- Freeze status: ready to close from the research-progress perspective

## Canonical Lines

### 1) Strict Comparable Line

Use this line when the emphasis is strict comparability under the original
formal training trajectory.

- Role: formal comparable line for Stage-1
- Representative checkpoint:
  - `work_dirs/tun3d_unposed_geoconf_v1_stable/epoch_9.pth`
- Training config:
  - `configs/tun3d_1xb16_scannet_s3dis_unposed_geoconf_v1_stable.py`
- Training log:
  - `work_dirs/tun3d_unposed_geoconf_v1_stable/20260422_172419/20260422_172419.log`
- Independent test log:
  - `work_dirs/eval_geoconf_ep9_nw0/20260423_161927/20260423_161927.log`

Independent test metrics (`test_dataloader.num_workers=0`):

- ScanNet: `mAP@0.25=0.4221`, `mAP@0.50=0.1909`, `layout F1@0.4=0.4698`
- S3DIS: `mAP@0.25=0.0919`, `mAP@0.50=0.0121`, `layout F1@0.4=0.1924`

### 2) Safe Continuation Line

Use this line when the emphasis is stability recovery and mechanism judgment
after the `epoch11` anomaly.

- Role: safe continuation line for Stage-1
- Representative checkpoint:
  - `work_dirs/tun3d_unposed_geoconf_v1_nan_debug_resume10/epoch_11.pth`
- Recovery config:
  - `configs/tun3d_1xb16_scannet_s3dis_unposed_geoconf_v1_nan_debug_resume10.py`
- Recovery log:
  - `work_dirs/tun3d_unposed_geoconf_v1_nan_debug_resume10/20260422_205213/20260422_205213.log`
- Independent test log:
  - `work_dirs/eval_geoconf_ep11_nw0/20260423_162214/20260423_162214.log`

Independent test metrics (`test_dataloader.num_workers=0`):

- ScanNet: `mAP@0.25=0.4192`, `mAP@0.50=0.1923`, `layout F1@0.4=0.4675`
- S3DIS: `mAP@0.25=0.0931`, `mAP@0.50=0.0120`, `layout F1@0.4=0.2019`

## Supporting Assets

- Bad checkpoint for anomaly reference:
  - `work_dirs/tun3d_unposed_geoconf_v1_stable/epoch_11_bad_nan.pth`
- Anomalous validation log:
  - `work_dirs/tun3d_unposed_geoconf_v1_stable/20260422_172419/20260422_172419.log`
- Additional independent tests:
  - `work_dirs/eval_geoconf_ep10_nw0/20260423_162103/20260423_162103.log`
  - `work_dirs/eval_geoconf_ep12_nw0/20260423_162323/20260423_162323.log`
- Short worker probes:
  - `work_dirs/probe_resume10_nw1_times2`
  - `work_dirs/probe_resume10_nw2_times2`
  - `work_dirs/probe_resume10_nw4_times2`

## One-Page Conclusion

Stage-1 `GeoConf-TUN3D` should be described as a mechanism-validation module,
not as the final downstream solution. Its main contribution is that it makes
the reconstruction feature reliability-aware before the sparse 3D network
starts learning from it. That is why its value should be framed as input-side
noise suppression instead of a generic feature enhancement trick.

The main mechanism-level conclusion is:

1. In the `unposed` setting, reconstruction noise is a real bottleneck and it
   propagates into both detection and layout understanding.
2. `GeoConf` mitigates this propagation at the feature entry point by reducing
   the influence of geometrically unreliable points.
3. The safe continuation run proves that `epoch11/12` is not a mandatory
   numerical collapse point for the method itself.

The main experimental conclusion is:

- `epoch_9.pth` is the best representative for the strict formal line.
- `epoch_11.pth` is the best representative for the safe continuation line.
- The gap between `epoch9` to `epoch12` is small, which suggests that Stage-1
  has largely reached its ceiling as an input modulation method.

The root-cause conclusion should stay conservative:

- The previous `epoch11 val=0` and `epoch12 NaN` event is highly suspiciously
  related to `multi-worker / batch path / random augmentation path`.
- However, the short `num_workers=1/2/4` probes did not reproduce the failure
  deterministically, so this should not be written as a fully proven root
  cause.

Therefore, Stage-1 is now frozen with a clear message:

- It solves an input-side mechanism problem.
- It validates the usefulness of reliability-aware reconstruction features.
- It is sufficient to support moving into Stage-2, where the reliability
  signal must be preserved during voxel aggregation instead of being used only
  once at the input.
