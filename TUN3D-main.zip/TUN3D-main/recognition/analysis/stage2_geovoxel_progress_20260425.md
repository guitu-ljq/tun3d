# Stage-2 GeoVoxel Progress

- Reference: `v2lite_lowclip`
- Generated from 21 runs

| Stage | Label | Epoch | ScanNet (0.25/0.50/F1) | S3DIS (0.25/0.50/F1) | Delta vs ref (SN50 / S350 / S3F1) |
| --- | --- | ---: | --- | --- | --- |
| baseline | v1_ref | 1 | 0.3788/0.1941/0.4750 | 0.1309/0.0101/0.2743 | +0.0103 / -0.0173 / -0.0403 |
| explicit_conf | v2lite_lowclip | 1 | 0.4006/0.1838/0.4938 | 0.1240/0.0274/0.3146 | 0.0000 / 0.0000 / 0.0000 |
| dual_path | v2p2_pctl_soft | 1 | 0.4278/0.1933/0.4654 | 0.1127/0.0207/0.3182 | +0.0096 / -0.0068 / +0.0036 |
| dual_path | v2p3_softblend | 1 | 0.4390/0.1929/0.5031 | 0.1106/0.0211/0.3152 | +0.0091 / -0.0063 / +0.0006 |
| dual_path | v2p3_midblend | 1 | 0.4061/0.2108/0.4969 | 0.1119/0.0224/0.3218 | +0.0271 / -0.0050 / +0.0072 |
| seed_replay | v2p3_mid_seed3407 | 2 | 0.4230/0.1938/0.4348 | 0.1177/0.0188/0.3295 | +0.0100 / -0.0086 / +0.0149 |
| seed_replay | v2p3_soft_seed3407 | 2 | 0.4239/0.1964/0.4348 | 0.1178/0.0189/0.3295 | +0.0126 / -0.0086 / +0.0149 |
| balanced | v2p4_balanced | 1 | 0.3927/0.1829/0.4906 | 0.1182/0.0236/0.3237 | -0.0009 / -0.0038 / +0.0091 |
| balanced | v2p4_balanced_layout | 1 | 0.4049/0.1836/0.3951 | 0.1080/0.0212/0.3240 | -0.0001 / -0.0062 / +0.0094 |
| density | v2p5_density_soft | 1 | 0.4160/0.1808/0.4750 | 0.1239/0.0228/0.3068 | -0.0030 / -0.0046 / -0.0078 |
| density | v2p5_density_mid | 1 | 0.3972/0.1798/0.4937 | 0.1212/0.0254/0.3584 | -0.0039 / -0.0021 / +0.0438 |
| density_weak | v2p6_density_weak_soft | 1 | 0.3976/0.1815/0.4224 | 0.1183/0.0247/0.3407 | -0.0022 / -0.0027 / +0.0261 |
| density_weak | v2p6_density_weak_mid | 1 | 0.4336/0.1942/0.5031 | 0.1133/0.0224/0.2955 | +0.0105 / -0.0050 / -0.0192 |
| density_sweep | v2p6_mid_d015 | 1 | 0.4308/0.1969/0.4348 | 0.1246/0.0225/0.3140 | +0.0132 / -0.0049 / -0.0007 |
| density_sweep | v2p6_mid_d020 | 1 | 0.3912/0.1875/0.4713 | 0.1247/0.0205/0.2659 | +0.0037 / -0.0069 / -0.0487 |
| density_sweep | v2p6_mid_d025 | 1 | 0.4370/0.1814/0.4277 | 0.1090/0.0223/0.2697 | -0.0024 / -0.0051 / -0.0449 |
| density_sweep | v2p6_mid_d030 | 1 | 0.4224/0.1855/0.4444 | 0.1110/0.0225/0.3596 | +0.0018 / -0.0049 / +0.0449 |
| support_reweight | v2p7_support_reweight_mid | 1 | 0.4241/0.1964/0.4596 | 0.1228/0.0211/0.2890 | +0.0126 / -0.0063 / -0.0256 |
| uncertainty_agg | v2p8_uncertainty_agg_mid | 1 | 0.4014/0.1912/0.4908 | 0.1183/0.0167/0.3295 | +0.0074 / -0.0107 / +0.0149 |
| short_run | v2p3_mid_2epoch | 2 | 0.4027/0.2042/0.4099 | 0.1154/0.0237/0.2874 | +0.0204 / -0.0037 / -0.0273 |
| short_run | v2p3_mid_4epoch | 4 | 0.4503/0.1816/0.4348 | 0.1292/0.0190/0.2793 | -0.0021 / -0.0084 / -0.0353 |

## Takeaways

- `v2lite_lowclip` 仍然是当前 S3DIS strict detection 的主要参考线。
- `v2p2_pctl_soft` 说明 percentile calibration 能抬 ScanNet strict detection，但代价是 S3DIS strict detection 偏弱。
- `v2p3_softblend` / `v2p3_midblend` 说明更保守的 calibration 确实能把 ScanNet strict detection 稳定到接近 `0.195` 附近。
- fixed-seed 复验里 `softblend` 与 `midblend` 非常接近，说明当前主矛盾已经从“有没有机制”转成“增益是否稳定可复现”。
- `v2p4` 用 `0.55` 的 norm blend 继续测试 soft/mid 之间的折中点，重点看是否能降低 seed 敏感性而不是追单次峰值。
- `v2p5_density_*` 证明显式 density 通道能补一部分 S3DIS strict detection，但会压低 ScanNet strict detection，需要继续做弱融合而不是强注入。
- `v2p6_density_weak_mid` 基本把 ScanNet strict detection 拉回到 `v2p3_softblend` 附近，但没有稳定保住 `v2p5` 的 S3DIS strict detection 增益。
- `v2p6_density_weak_soft` 只保住了很小的 S3DIS strict detection 补偿，且 ScanNet / layout 都不如预期，说明 density 弱融合的强度窗口还比较窄。
- 进一步对 `v2p6_density_weak_mid` 做 `0.15 / 0.20 / 0.25 / 0.30` 的 density sweep 后，没有出现同时优于 `v2p3_midblend` 的点，说明显式 density 通道目前更像是 trade-off 旋钮，而不是稳定增益来源。
- 这轮 sweep 里 `v2p6_mid_d015` 是最接近可用的折中点，但也只是把 ScanNet `mAP@0.50` 维持在 `0.1969`，S3DIS `mAP@0.50` 仅 `0.0225`，没有形成值得继续推进 full-run 的新主线。
- `v2p7_support_reweight_mid` 进一步验证了 density 即便不进 backbone、只做轻量 aggregation reweight，也还没有带来净增益，说明当前主矛盾更可能在 uncertainty/layout consistency，而不是 support 先验本身。
- `v2p8_uncertainty_agg_mid` 说明简单的体素内 confidence variance 惩罚会进一步压低 strict detection，当前说明“估计不确定性”本身没错，但这个版本的 uncertainty proxy 过于粗糙，容易把真实边界/稀疏目标也一起抑制。
- `v2p3_mid_4epoch` 没有把 ScanNet `mAP@0.50` 稳定维持在 `0.20+`，因此现阶段不建议直接推进 full-run。

## Logs

- `v1_ref`: `/autodl-fs/data/TUN3D-main/recognition/work_dirs/geovoxel_quick_sweep/v1_ref/20260424_213404/20260424_213404.log`
- `v2lite_lowclip`: `/autodl-fs/data/TUN3D-main/recognition/work_dirs/geovoxel_quick_sweep/v2lite_lowclip/20260424_213710/20260424_213710.log`
- `v2p2_pctl_soft`: `/autodl-fs/data/TUN3D-main/recognition/work_dirs/geovoxel_quick_sweep/v2p2_dualpath_pctl_soft/20260425_152506/20260425_152506.log`
- `v2p3_softblend`: `/autodl-fs/data/TUN3D-main/recognition/work_dirs/geovoxel_quick_sweep/v2p3_dualpath_pctl_softblend/20260425_154340/20260425_154340.log`
- `v2p3_midblend`: `/autodl-fs/data/TUN3D-main/recognition/work_dirs/geovoxel_quick_sweep/v2p3_dualpath_pctl_midblend/20260425_154435/20260425_154435.log`
- `v2p3_mid_seed3407`: `/autodl-fs/data/TUN3D-main/recognition/work_dirs/geovoxel_quick_sweep/v2p3_midblend_seed3407_2epoch/20260425_161648/20260425_161648.log`
- `v2p3_soft_seed3407`: `/autodl-fs/data/TUN3D-main/recognition/work_dirs/geovoxel_quick_sweep/v2p3_softblend_seed3407_2epoch/20260425_161806/20260425_161806.log`
- `v2p4_balanced`: `/autodl-fs/data/TUN3D-main/recognition/work_dirs/geovoxel_quick_sweep/v2p4_dualpath_balanced/20260425_163714/20260425_163714.log`
- `v2p4_balanced_layout`: `/autodl-fs/data/TUN3D-main/recognition/work_dirs/geovoxel_quick_sweep/v2p4_dualpath_balanced_layout/20260425_163823/20260425_163823.log`
- `v2p5_density_soft`: `/autodl-fs/data/TUN3D-main/recognition/work_dirs/geovoxel_quick_sweep/v2p5_density_soft/20260425_165111/20260425_165111.log`
- `v2p5_density_mid`: `/autodl-fs/data/TUN3D-main/recognition/work_dirs/geovoxel_quick_sweep/v2p5_density_mid/20260425_165205/20260425_165205.log`
- `v2p6_density_weak_soft`: `/autodl-fs/data/TUN3D-main/recognition/work_dirs/geovoxel_quick_sweep/v2p6_density_weak_soft/20260425_170156/20260425_170156.log`
- `v2p6_density_weak_mid`: `/autodl-fs/data/TUN3D-main/recognition/work_dirs/geovoxel_quick_sweep/v2p6_density_weak_mid/20260425_170250/20260425_170250.log`
- `v2p6_mid_d015`: `/autodl-fs/data/TUN3D-main/recognition/work_dirs/geovoxel_quick_sweep/v2p6_mid_d015/20260425_171403/20260425_171403.log`
- `v2p6_mid_d020`: `/autodl-fs/data/TUN3D-main/recognition/work_dirs/geovoxel_quick_sweep/v2p6_mid_d020/20260425_171456/20260425_171456.log`
- `v2p6_mid_d025`: `/autodl-fs/data/TUN3D-main/recognition/work_dirs/geovoxel_quick_sweep/v2p6_mid_d025/20260425_171548/20260425_171548.log`
- `v2p6_mid_d030`: `/autodl-fs/data/TUN3D-main/recognition/work_dirs/geovoxel_quick_sweep/v2p6_mid_d030/20260425_171641/20260425_171641.log`
- `v2p7_support_reweight_mid`: `/autodl-fs/data/TUN3D-main/recognition/work_dirs/geovoxel_quick_sweep/v2p7_support_reweight_mid/20260425_173843/20260425_173843.log`
- `v2p8_uncertainty_agg_mid`: `/autodl-fs/data/TUN3D-main/recognition/work_dirs/geovoxel_quick_sweep/v2p8_uncertainty_agg_mid/20260425_174906/20260425_174906.log`
- `v2p3_mid_2epoch`: `/autodl-fs/data/TUN3D-main/recognition/work_dirs/geovoxel_quick_sweep/v2p3_midblend_2epoch/20260425_155215/20260425_155215.log`
- `v2p3_mid_4epoch`: `/autodl-fs/data/TUN3D-main/recognition/work_dirs/geovoxel_quick_sweep/v2p3_midblend_4epoch/20260425_160115/20260425_160115.log`
