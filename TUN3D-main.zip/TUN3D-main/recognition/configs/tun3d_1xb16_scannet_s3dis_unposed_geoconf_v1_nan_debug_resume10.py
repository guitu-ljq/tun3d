_base_ = ['./tun3d_1xb16_scannet_s3dis_unposed_geoconf_v1_stable.py']

# Debug replay from epoch10 to catch the first bad iteration with per-iter logs.

default_hooks = dict(
    logger=dict(type='LoggerHook', interval=1),
    checkpoint=dict(interval=1, max_keep_ckpts=3),
)

# Keep cache clearing, but add a fail-fast finite-value guard.
custom_hooks = [
    dict(type='EmptyCacheHook', after_iter=True),
    dict(type='NaNGuardHook', check_params=True, check_grads=True),
]

# Slower but easier-to-debug data loading.
train_dataloader = dict(
    batch_size=8,
    num_workers=0,
)

val_dataloader = dict(num_workers=0)

# Use a separate work dir to preserve the original formal run.
work_dir = 'work_dirs/tun3d_unposed_geoconf_v1_nan_debug_resume10'
