_base_ = ['./tun3d_1xb16_scannet_s3dis_unposed_geoconf_v1.py']

# Warm start from the released unposed baseline, but use a gentler
# optimization setup because GeoConf changes the input color statistics.
load_from = 'work_dirs/checkpoints/tun3d_scannet_s3dis_unposed.pth'

EPOCHS = 1
train_cfg = dict(type='EpochBasedTrainLoop', max_epochs=EPOCHS, val_interval=1)

train_dataloader = dict(
    batch_size=8,
    num_workers=4,
    dataset=dict(times=1),
)

# Disable AMP for the stability probe and lower the learning rate.
optim_wrapper = dict(
    type='OptimWrapper',
    optimizer=dict(type='AdamW', lr=1e-4, weight_decay=0.0001),
    clip_grad=dict(max_norm=5, norm_type=2),
)

# A short warmup helps the classifier adapt to the new GeoConf-modulated
# color distribution before reaching the full learning rate.
param_scheduler = [
    dict(
        type='LinearLR',
        start_factor=0.2,
        by_epoch=False,
        begin=0,
        end=50,
    )
]

default_hooks = dict(checkpoint=dict(interval=1, max_keep_ckpts=2))
