_base_ = ['./tun3d_1xb16_scannet_s3dis_unposed_geoconf_v1.py']

# Stable formal run: keep the GeoConf warm start, but use the
# numerically safe setup validated by the NaN probe.
load_from = 'work_dirs/checkpoints/tun3d_scannet_s3dis_unposed.pth'

EPOCHS = 12
train_cfg = dict(type='EpochBasedTrainLoop', max_epochs=EPOCHS, val_interval=1)

train_dataloader = dict(
    batch_size=8,
    num_workers=4,
    dataset=dict(times=15),
)

optim_wrapper = dict(
    type='OptimWrapper',
    optimizer=dict(type='AdamW', lr=1e-4, weight_decay=0.0001),
    clip_grad=dict(max_norm=5, norm_type=2),
)

param_scheduler = [
    dict(
        type='LinearLR',
        start_factor=0.2,
        by_epoch=False,
        begin=0,
        end=200,
    ),
    dict(
        type='MultiStepLR',
        begin=0,
        end=EPOCHS,
        by_epoch=True,
        milestones=[8, 11],
        gamma=0.1,
    ),
]

default_hooks = dict(checkpoint=dict(interval=1, max_keep_ckpts=3))
