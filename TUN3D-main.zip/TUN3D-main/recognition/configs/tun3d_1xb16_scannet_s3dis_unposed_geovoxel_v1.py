_base_ = ['./tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v0.py']

model = dict(
    voxel_conf_mode='mean',
    voxel_conf_power=0.5,
    voxel_conf_blend=0.5,
)

work_dir = 'work_dirs/tun3d_unposed_geovoxel_v1'
