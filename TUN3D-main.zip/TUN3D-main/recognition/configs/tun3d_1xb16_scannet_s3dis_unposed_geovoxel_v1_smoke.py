_base_ = ['./tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v1.py']

work_dir = 'work_dirs/tun3d_unposed_geovoxel_v1_smoke'

EPOCHS = 1
train_cfg = dict(type='EpochBasedTrainLoop', max_epochs=EPOCHS, val_interval=1)

train_dataloader = dict(
    batch_size=4,
    num_workers=0,
    sampler=dict(type='DefaultSampler', shuffle=True),
    dataset=dict(
        type='RepeatDataset',
        times=2,
        dataset=dict(
            type='ConcatDataset_',
            datasets=[
                dict(
                    type='ScanNetDataset',
                    data_root='../data/scannet',
                    data_prefix=dict(pts='points_unposed_geoconf_v2_smoke'),
                    ann_file='scannet_layout_infos_train_smoke.pkl',
                    pipeline={{_base_.train_pipeline_scannet}},
                    filter_empty_gt=False,
                    metainfo={{_base_.metainfo}},
                    box_type_3d='Depth',
                    backend_args=None),
                dict(
                    type='ConcatDataset',
                    datasets=[dict(
                        type='S3DISDataset',
                        data_root='../data/s3dis',
                        data_prefix=dict(pts='points_unposed_geoconf_v2_smoke'),
                        ann_file=f's3dis_layout_infos_Area_{i}_unposed_smoke.pkl',
                        pipeline={{_base_.train_pipeline_s3dis}},
                        filter_empty_gt=False,
                        metainfo={{_base_.metainfo_s3dis}},
                        box_type_3d='Depth',
                        backend_args=None) for i in [1, 2, 3, 4, 6]])
            ])))

val_dataloader = dict(
    batch_size=1,
    num_workers=0,
    sampler=dict(type='DefaultSampler', shuffle=False),
    dataset=dict(
        type='ConcatDataset_',
        datasets=[
            dict(
                type='ScanNetDataset',
                data_root='../data/scannet',
                data_prefix=dict(pts='points_unposed_geoconf_v2_smoke'),
                ann_file='scannet_layout_infos_val_smoke.pkl',
                pipeline={{_base_.test_pipeline_scannet}},
                metainfo={{_base_.metainfo}},
                test_mode=True,
                box_type_3d='Depth',
                backend_args=None),
            dict(
                type='S3DISDataset',
                data_root='../data/s3dis',
                data_prefix=dict(pts='points_unposed_geoconf_v2_smoke'),
                ann_file='s3dis_layout_infos_Area_5_unposed_smoke.pkl',
                pipeline={{_base_.test_pipeline_s3dis}},
                metainfo={{_base_.metainfo_s3dis}},
                test_mode=True,
                box_type_3d='Depth',
                backend_args=None)
        ]))

test_dataloader = val_dataloader

default_hooks = dict(checkpoint=dict(interval=1, max_keep_ckpts=1))
