_base_ = ['./tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v2_lite.py']

model = dict(
    voxel_feature_mode='scaled_rgb_raw_conf',
    voxel_conf_blend=0.35,
    voxel_conf_min=0.02,
    backbone=dict(in_channels=7),
)

work_dir = 'work_dirs/tun3d_unposed_geovoxel_v2_1'
