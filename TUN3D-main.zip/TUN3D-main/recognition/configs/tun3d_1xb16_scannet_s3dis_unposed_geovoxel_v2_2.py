_base_ = ['./tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v2_1.py']

model = dict(
    point_conf_norm_mode='scene_percentile',
    point_conf_quantile_low=0.05,
    point_conf_quantile_high=0.95,
)

work_dir = 'work_dirs/tun3d_unposed_geovoxel_v2_2'
