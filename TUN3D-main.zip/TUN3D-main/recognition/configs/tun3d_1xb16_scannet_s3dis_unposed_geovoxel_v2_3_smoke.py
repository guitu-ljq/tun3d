_base_ = ['./tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v2_2_smoke.py']

model = dict(
    point_conf_norm_blend=0.5,
    point_conf_quantile_low=0.10,
    point_conf_quantile_high=0.90,
    voxel_conf_power=0.25,
)

work_dir = 'work_dirs/tun3d_unposed_geovoxel_v2_3_smoke'
