_base_ = ['./tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v2_3_smoke.py']

model = dict(
    voxel_feature_mode='scaled_rgb_raw_conf_count',
    backbone=dict(in_channels=8),
)

work_dir = 'work_dirs/tun3d_unposed_geovoxel_v2_5_smoke'
