_base_ = ['./tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v2_3.py']

model = dict(
    point_conf_norm_blend=0.65,
    voxel_support_reweight_blend=0.20,
)

work_dir = 'work_dirs/tun3d_unposed_geovoxel_v2_7'
