_base_ = ['./tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v2_3.py']

model = dict(
    voxel_feature_mode='scaled_rgb_raw_conf_unified_gate',
    voxel_unified_gate_blend=0.30,
)

load_from = 'work_dirs/pretrained/tun3d_unposed_geoconf_v1_epoch_11_in7_mean.pth'
work_dir = 'work_dirs/tun3d_unposed_geovoxel_v2_9a'
