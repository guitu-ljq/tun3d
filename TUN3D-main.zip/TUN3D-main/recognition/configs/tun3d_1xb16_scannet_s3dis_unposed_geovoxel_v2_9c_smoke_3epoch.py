_base_ = ['./tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v2_9c_smoke.py']

EPOCHS = 3
train_cfg = dict(type='EpochBasedTrainLoop', max_epochs=EPOCHS, val_interval=1)

work_dir = 'work_dirs/tun3d_unposed_geovoxel_v2_9c_smoke_3epoch'
