_base_ = ['./tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v1.py']

model = dict(
    voxel_feature_mode='scaled_rgb_conf',
    backbone=dict(in_channels=4),
)

work_dir = 'work_dirs/tun3d_unposed_geovoxel_v2_lite'
