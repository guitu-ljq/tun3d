_base_ = ['./tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v2_3.py']

model = dict(
    bbox_head=dict(
        det_feature_modulation='residual_scalar_gate',
        det_feature_modulation_blend=0.20,
        det_feature_apply_to='reg',
        det_context_kernel_size=3,
    ))

work_dir = 'work_dirs/tun3d_unposed_geovoxel_v3_2a'
