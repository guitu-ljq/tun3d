_base_ = ['./tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v3_2c_smoke.py']

model = dict(
    bbox_head=dict(
        layout_feature_modulation='residual_scalar_gate',
        layout_feature_modulation_blend=0.10,
    ))

work_dir = 'work_dirs/tun3d_unposed_geovoxel_v3_2c_layoutsafe_smoke'
