_base_ = ['./tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v3_3_smoke.py']

model = dict(
    bbox_head=dict(
        branch_detail_blend_reg=0.30,
        branch_stable_blend_cls=0.05,
        branch_stable_blend_layout=0.15,
    ))

work_dir = 'work_dirs/tun3d_unposed_geovoxel_v3_3a_smoke'
