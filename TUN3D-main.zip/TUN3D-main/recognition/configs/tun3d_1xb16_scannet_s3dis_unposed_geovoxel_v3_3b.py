_base_ = ['./tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v3_3.py']

model = dict(
    bbox_head=dict(
        branch_reliability_split='stable_detail_confidence',
        branch_detail_blend_reg=0.20,
        branch_stable_blend_cls=0.05,
        branch_stable_blend_layout=0.20,
        branch_confidence_bias_cls=0.80,
        branch_confidence_bias_layout=0.55,
        branch_confidence_power_reg=1.5,
    ))

work_dir = 'work_dirs/tun3d_unposed_geovoxel_v3_3b'
