_base_ = ['./tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v2_3.py']

model = dict(
    voxel_feature_mode='scaled_rgb_detail_conf',
    voxel_detail_blend=0.35,
    bbox_head=dict(
        det_feature_modulation='none',
        layout_feature_modulation='none',
        branch_reliability_split='none',
        expert_routing_mode='task_moe',
        expert_kernel_size=3,
        gate_with_confidence=True,
        gate_temperature=1.0,
        layout_expert_prior=(0.60, 0.15, 0.25),
        cls_expert_prior=(0.35, 0.30, 0.35),
        reg_expert_prior=(0.15, 0.65, 0.20),
    ))

work_dir = 'work_dirs/tun3d_unposed_geovoxel_v4_0_min'
