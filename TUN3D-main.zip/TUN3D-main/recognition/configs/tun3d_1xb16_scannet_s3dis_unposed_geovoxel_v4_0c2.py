_base_ = ['./tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v2_3.py']

model = dict(
    voxel_feature_mode='scaled_rgb_detail_conf',
    voxel_detail_blend=0.35,
    bbox_head=dict(
        det_feature_modulation='none',
        layout_feature_modulation='none',
        branch_reliability_split='none',
        expert_routing_mode='task_moe',
        expert_kernel_size=3,
        gate_with_confidence=True,
        gate_temperature=2.0,
        layout_expert_prior=(1.0, 1.0, 1.0),
        cls_expert_prior=(1.0, 1.0, 1.0),
        reg_expert_prior=(1.0, 1.0, 1.0),
        expert_route_blend_layout=0.10,
        expert_route_blend_cls=0.00,
        expert_route_blend_reg=0.10,
        dataset_gate_mode='dataset_bias',
        dataset_gate_apply_to='layout_reg',
        dataset_gate_bias_scale=1.0,
        dataset_gate_reg_weight=0.001,
        dataset_prior_bias_scale=0.50,
        dataset_prior_confidence_mode='layout_low_reg_high',
        dataset_prior_confidence_strength=0.75,
        dataset_prior_confidence_power=1.0,
        dataset_layout_expert_priors=((0.55, 0.20, 0.25),
                                      (0.70, 0.10, 0.20)),
        dataset_reg_expert_priors=((0.15, 0.65, 0.20),
                                   (0.40, 0.35, 0.25)),
        uncertainty_weight_mode='dataset_task_logvar',
    ))

work_dir = 'work_dirs/tun3d_unposed_geovoxel_v4_0c2'
