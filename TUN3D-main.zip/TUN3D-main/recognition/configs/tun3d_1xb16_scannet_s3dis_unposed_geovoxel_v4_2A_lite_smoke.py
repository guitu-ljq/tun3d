_base_ = ['./tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v4_0a_smoke.py']

model = dict(
    neck=dict(
        type='TUN3DLateSplitNeck',
        in_channels=(64, 128, 128, 128),
        out_channels=128,
        split_levels=(1,),
        layout_split_blend=1.0,
        det_split_blend=0.0,
        split_kernel_size=3,
    ),
    bbox_head=dict(
        layout_feature_source='neck_split',
    ))

work_dir = 'work_dirs/tun3d_unposed_geovoxel_v4_2A_lite_smoke'
