_base_ = ['./tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v4_2b0_smoke.py']

model = dict(
    bbox_head=dict(
        layout_boundary_loss=dict(
            type='LayoutBoundaryLoss',
            reduction='none',
            center_weight=0.5,
            length_weight=0.75,
            direction_weight=1.0,
            height_weight=0.25,
        ),
        layout_boundary_loss_weight=0.20,
    ))

work_dir = 'work_dirs/tun3d_unposed_geovoxel_v4_2B_complete_smoke'
