_base_ = ['./tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v4_0a_smoke.py']

model = dict(
    conflict_optim_mode='cagrad',
    cagrad_alpha=0.5,
    cagrad_rescale=1,
    cagrad_shared_param_mode='backbone_neck',
    cagrad_grid_points=101,
)

work_dir = 'work_dirs/tun3d_unposed_geovoxel_v4_2b0_smoke'
