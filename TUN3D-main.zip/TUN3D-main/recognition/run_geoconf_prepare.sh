#!/bin/bash
set -e

source /root/miniconda3/etc/profile.d/conda.sh
conda activate tun3d

cd /autodl-fs/data/TUN3D-main/recognition
export OMP_NUM_THREADS=1
export PYTHONPATH="$(pwd):$PYTHONPATH"

python tools/build_geoconf_bins.py \
  --src ../data/scannet/points_unposed \
  --dst ../data/scannet/points_unposed_geoconf_v1 \
  --k 16 \
  --alpha 0.7

python tools/build_geoconf_bins.py \
  --src ../data/s3dis/points_unposed \
  --dst ../data/s3dis/points_unposed_geoconf_v1 \
  --k 16 \
  --alpha 0.7

echo "GeoConf data prepared at:"
echo "  ../data/scannet/points_unposed_geoconf_v1"
echo "  ../data/s3dis/points_unposed_geoconf_v1"
