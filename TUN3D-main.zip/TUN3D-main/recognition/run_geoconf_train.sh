#!/bin/bash
set -e

source /root/miniconda3/etc/profile.d/conda.sh
conda activate tun3d

cd /autodl-fs/data/TUN3D-main/recognition
export OMP_NUM_THREADS=1
export PYTHONPATH="$(pwd):$PYTHONPATH"

python tools/train.py \
  configs/tun3d_1xb16_scannet_s3dis_unposed_geoconf_v1.py \
  --work-dir work_dirs/tun3d_unposed_geoconf_v1 \
  --amp
