#!/bin/bash
set -e

source /root/miniconda3/etc/profile.d/conda.sh
conda activate tun3d

cd /autodl-fs/data/TUN3D-main/recognition
export OMP_NUM_THREADS=1
export PYTHONPATH="$(pwd):$PYTHONPATH"

python tools/geovoxel_v3_diagnose.py \
  --project-root /autodl-fs/data/TUN3D-main \
  "$@"
