"""
Generate GeoConf-modulated point clouds for unposed TUN3D experiments.

Input format:
  float32 binary, shape (N, 6), [x, y, z, r, g, b]

Output format:
  float32 binary, shape (N, 6), [x, y, z, r*conf, g*conf, b*conf]

This keeps the point dimension unchanged so the existing TUN3D loaders,
transforms and model configs can be reused without modifying channels.
"""

import argparse
import glob
import os

import numpy as np
from scipy.spatial import cKDTree
from tqdm import tqdm


def normalize01(values: np.ndarray) -> np.ndarray:
    values = values.astype(np.float32, copy=False)
    min_value = float(values.min())
    max_value = float(values.max())
    if max_value - min_value < 1e-8:
        return np.ones_like(values, dtype=np.float32)
    return (values - min_value) / (max_value - min_value + 1e-8)


def estimate_geo_confidence(
    xyz: np.ndarray, k: int = 16, alpha: float = 0.7
) -> np.ndarray:
    """Estimate point-wise geometric confidence from local density + roughness."""
    num_points = xyz.shape[0]
    if num_points < k + 1:
        return np.full(num_points, 0.5, dtype=np.float32)

    tree = cKDTree(xyz)
    distances, indices = tree.query(xyz, k=k + 1)
    neighbor_distances = distances[:, 1:]
    neighbor_indices = indices[:, 1:]

    mean_distance = neighbor_distances.mean(axis=1)
    density = 1.0 / (mean_distance + 1e-6)
    density_norm = normalize01(density)

    roughness = np.zeros(num_points, dtype=np.float32)
    for point_index in range(num_points):
        neighbors = xyz[neighbor_indices[point_index]]
        centered = neighbors - neighbors.mean(axis=0, keepdims=True)
        covariance = (centered.T @ centered) / max(len(centered) - 1, 1)
        eigenvalues = np.linalg.eigvalsh(covariance)
        total = float(eigenvalues.sum())
        if total > 1e-10:
            roughness[point_index] = eigenvalues[0] / total

    roughness_norm = normalize01(roughness)
    confidence = alpha * density_norm + (1.0 - alpha) * (1.0 - roughness_norm)
    return np.clip(confidence, 0.05, 1.0).astype(np.float32)


def estimate_geo_confidence_fast(xyz: np.ndarray, k: int = 16) -> np.ndarray:
    """Fast ablation version using only local density."""
    num_points = xyz.shape[0]
    if num_points < k + 1:
        return np.full(num_points, 0.5, dtype=np.float32)

    tree = cKDTree(xyz)
    distances, _ = tree.query(xyz, k=k + 1)
    mean_distance = distances[:, 1:].mean(axis=1)
    density = 1.0 / (mean_distance + 1e-6)
    confidence = normalize01(density)
    return np.clip(confidence, 0.05, 1.0).astype(np.float32)


def process_file(
    src_path: str, dst_path: str, k: int = 16, alpha: float = 0.7, fast: bool = False
) -> dict:
    data = np.fromfile(src_path, dtype=np.float32)
    if len(data) % 6 != 0:
        raise ValueError(f"{src_path}: invalid length {len(data)}, expected 6D points")

    points = data.reshape(-1, 6)
    xyz = points[:, :3]
    rgb = points[:, 3:6]

    if fast:
        confidence = estimate_geo_confidence_fast(xyz, k=k)
    else:
        confidence = estimate_geo_confidence(xyz, k=k, alpha=alpha)

    rgb_modulated = rgb * confidence[:, None]
    output = np.concatenate([xyz, rgb_modulated], axis=1).astype(np.float32)
    output.tofile(dst_path)

    return {
        "num_points": int(points.shape[0]),
        "conf_mean": float(confidence.mean()),
        "conf_min": float(confidence.min()),
        "conf_max": float(confidence.max()),
        "low_ratio": float((confidence < 0.3).mean()),
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Generate 6D GeoConf point clouds for unposed TUN3D."
    )
    parser.add_argument("--src", required=True, help="Source directory of .bin files")
    parser.add_argument("--dst", required=True, help="Destination directory of .bin files")
    parser.add_argument("--k", type=int, default=16, help="KNN neighborhood size")
    parser.add_argument(
        "--alpha",
        type=float,
        default=0.7,
        help="Density weight in GeoConf fusion",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=-1,
        help="Only process the first N files, use -1 for all",
    )
    parser.add_argument(
        "--fast",
        action="store_true",
        help="Use density-only confidence for fast ablation",
    )
    parser.add_argument(
        "--skip-existing",
        action="store_true",
        help="Skip files that already exist in the destination directory",
    )
    args = parser.parse_args()

    os.makedirs(args.dst, exist_ok=True)

    file_paths = sorted(glob.glob(os.path.join(args.src, "*.bin")))
    if args.limit > 0:
        file_paths = file_paths[: args.limit]

    print(f"num_files={len(file_paths)}")
    print(f"k={args.k}, alpha={args.alpha}, fast={args.fast}")
    print(f"src={args.src}")
    print(f"dst={args.dst}")

    stats = []
    failures = 0
    for src_path in tqdm(file_paths, desc="GeoConf"):
        file_name = os.path.basename(src_path)
        dst_path = os.path.join(args.dst, file_name)
        if args.skip_existing and os.path.exists(dst_path):
            continue
        try:
            stats.append(
                process_file(
                    src_path=src_path,
                    dst_path=dst_path,
                    k=args.k,
                    alpha=args.alpha,
                    fast=args.fast,
                )
            )
        except Exception as exc:  # pragma: no cover - debug logging path
            print(f"skip {file_name}: {exc}")
            failures += 1

    print("=" * 48)
    print(f"done={len(stats)}/{len(file_paths)}, failed={failures}")
    if stats:
        print(f"avg_conf_mean={np.mean([item['conf_mean'] for item in stats]):.4f}")
        print(f"avg_low_ratio={np.mean([item['low_ratio'] for item in stats]):.4f}")
    print("=" * 48)


if __name__ == "__main__":
    main()
