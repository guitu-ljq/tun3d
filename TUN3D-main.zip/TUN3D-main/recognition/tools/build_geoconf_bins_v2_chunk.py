"""Chunked GeoConf v2 builder for parallel full-data generation."""

import argparse
import glob
import os

from build_geoconf_bins_v2 import process_file


def main() -> None:
    parser = argparse.ArgumentParser(description='Build a chunk of GeoConf v2 bins.')
    parser.add_argument('--src', required=True)
    parser.add_argument('--dst', required=True)
    parser.add_argument('--start', type=int, required=True)
    parser.add_argument('--end', type=int, required=True)
    parser.add_argument('--k', type=int, default=16)
    parser.add_argument('--alpha', type=float, default=0.7)
    parser.add_argument('--fast', action='store_true')
    parser.add_argument('--skip-existing', action='store_true')
    args = parser.parse_args()

    os.makedirs(args.dst, exist_ok=True)
    file_paths = sorted(glob.glob(os.path.join(args.src, '*.bin')))
    chunk = file_paths[args.start:args.end]

    print(f'chunk_start={args.start} chunk_end={args.end} num_files={len(chunk)}')
    for idx, src_path in enumerate(chunk, start=args.start):
        file_name = os.path.basename(src_path)
        dst_path = os.path.join(args.dst, file_name)
        if args.skip_existing and os.path.exists(dst_path):
            continue
        process_file(
            src_path=src_path,
            dst_path=dst_path,
            k=args.k,
            alpha=args.alpha,
            fast=args.fast,
        )
        if (idx - args.start + 1) % 10 == 0:
            print(f'processed={idx - args.start + 1}/{len(chunk)} last={file_name}', flush=True)

    print('chunk_done')


if __name__ == '__main__':
    main()
