import argparse
import json
from pathlib import Path
from typing import Dict, List, Tuple

from geovoxel_log_utils import extract_latest_val_metrics


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description='Evaluate whether a GeoVoxel short run should be promoted.')
    parser.add_argument('--log', required=True, help='Log file to evaluate.')
    parser.add_argument(
        '--ref-log',
        help='Reference log file. When provided, thresholds become relative.')
    parser.add_argument(
        '--max-scannet-map50-drop',
        type=float,
        default=0.005,
        help='Allowed absolute drop on ScanNet mAP@0.50 versus reference.')
    parser.add_argument(
        '--max-scannet-layout-drop',
        type=float,
        default=0.01,
        help='Allowed absolute drop on ScanNet layout F1 versus reference.')
    parser.add_argument(
        '--min-s3dis-map25-delta',
        type=float,
        default=0.0,
        help='Required delta on S3DIS mAP@0.25 versus reference.')
    parser.add_argument(
        '--max-s3dis-layout-drop',
        type=float,
        default=0.01,
        help='Allowed absolute drop on S3DIS layout F1 versus reference.')
    parser.add_argument(
        '--min-scannet-map50',
        type=float,
        default=None,
        help='Absolute floor for ScanNet mAP@0.50 when no reference is used.')
    parser.add_argument(
        '--min-s3dis-map25',
        type=float,
        default=None,
        help='Absolute floor for S3DIS mAP@0.25 when no reference is used.')
    parser.add_argument(
        '--min-scannet-layout',
        type=float,
        default=None,
        help='Absolute floor for ScanNet layout F1 when no reference is used.')
    parser.add_argument(
        '--min-s3dis-layout',
        type=float,
        default=None,
        help='Absolute floor for S3DIS layout F1 when no reference is used.')
    parser.add_argument(
        '--json',
        action='store_true',
        help='Print the final gate result as JSON.')
    return parser.parse_args()


def evaluate_against_reference(
    metrics: Dict[str, float],
    reference: Dict[str, float],
    args: argparse.Namespace,
) -> Tuple[bool, List[str]]:
    checks = [
        (
            metrics['scannet_map50'] >=
            reference['scannet_map50'] - args.max_scannet_map50_drop,
            'scannet_map50',
            metrics['scannet_map50'],
            reference['scannet_map50'] - args.max_scannet_map50_drop,
            '>=',
        ),
        (
            metrics['scannet_layout_f1'] >=
            reference['scannet_layout_f1'] - args.max_scannet_layout_drop,
            'scannet_layout_f1',
            metrics['scannet_layout_f1'],
            reference['scannet_layout_f1'] - args.max_scannet_layout_drop,
            '>=',
        ),
        (
            metrics['s3dis_map25'] >=
            reference['s3dis_map25'] + args.min_s3dis_map25_delta,
            's3dis_map25',
            metrics['s3dis_map25'],
            reference['s3dis_map25'] + args.min_s3dis_map25_delta,
            '>=',
        ),
        (
            metrics['s3dis_layout_f1'] >=
            reference['s3dis_layout_f1'] - args.max_s3dis_layout_drop,
            's3dis_layout_f1',
            metrics['s3dis_layout_f1'],
            reference['s3dis_layout_f1'] - args.max_s3dis_layout_drop,
            '>=',
        ),
    ]
    return summarize_checks(checks)


def evaluate_with_absolute_floors(
    metrics: Dict[str, float],
    args: argparse.Namespace,
) -> Tuple[bool, List[str]]:
    checks = []
    if args.min_scannet_map50 is not None:
        checks.append((
            metrics['scannet_map50'] >= args.min_scannet_map50,
            'scannet_map50',
            metrics['scannet_map50'],
            args.min_scannet_map50,
            '>=',
        ))
    if args.min_s3dis_map25 is not None:
        checks.append((
            metrics['s3dis_map25'] >= args.min_s3dis_map25,
            's3dis_map25',
            metrics['s3dis_map25'],
            args.min_s3dis_map25,
            '>=',
        ))
    if args.min_scannet_layout is not None:
        checks.append((
            metrics['scannet_layout_f1'] >= args.min_scannet_layout,
            'scannet_layout_f1',
            metrics['scannet_layout_f1'],
            args.min_scannet_layout,
            '>=',
        ))
    if args.min_s3dis_layout is not None:
        checks.append((
            metrics['s3dis_layout_f1'] >= args.min_s3dis_layout,
            's3dis_layout_f1',
            metrics['s3dis_layout_f1'],
            args.min_s3dis_layout,
            '>=',
        ))
    return summarize_checks(checks)


def summarize_checks(
    checks: List[Tuple[bool, str, float, float, str]]
) -> Tuple[bool, List[str]]:
    reasons = []
    passed = True
    for ok, name, value, threshold, op in checks:
        tag = 'PASS' if ok else 'FAIL'
        reasons.append(
            f'[{tag}] {name}: {value:.4f} {op} {threshold:.4f}')
        passed &= ok
    return passed, reasons


def main() -> None:
    args = parse_args()
    result = extract_latest_val_metrics(Path(args.log))
    metrics = result['metrics']

    if args.ref_log:
        ref_result = extract_latest_val_metrics(Path(args.ref_log))
        passed, reasons = evaluate_against_reference(
            metrics, ref_result['metrics'], args)
        reference = ref_result['metrics']
    else:
        passed, reasons = evaluate_with_absolute_floors(metrics, args)
        reference = None

    output = dict(
        passed=passed,
        epoch=result['epoch'],
        metrics=metrics,
        reference=reference,
        reasons=reasons,
        log=args.log,
    )

    if args.json:
        print(json.dumps(output, indent=2, sort_keys=True))
        return

    print(f'Gate result: {"PASS" if passed else "FAIL"}')
    print(f'Log: {args.log}')
    print(f'Epoch: {result["epoch"]}')
    for key, value in metrics.items():
        print(f'  - {key}: {value:.4f}')
    for reason in reasons:
        print(f'  - {reason}')


if __name__ == '__main__':
    main()
