import ast
from pathlib import Path
from typing import Dict, Iterable, Optional


MetricDict = Dict[str, Dict[str, float]]


def _parse_val_line(line: str) -> Optional[MetricDict]:
    if 'Epoch(val)' not in line or 'scannet:' not in line or 's3dis:' not in line:
        return None

    scannet_key = 'scannet:'
    s3dis_key = 's3dis:'
    data_time_key = 'data_time:'

    scannet_start = line.find(scannet_key)
    s3dis_start = line.find(s3dis_key)
    data_time_start = line.rfind(data_time_key)
    if scannet_start == -1 or s3dis_start == -1 or data_time_start == -1:
        return None

    scannet_str = line[scannet_start + len(scannet_key):s3dis_start].strip()
    s3dis_str = line[s3dis_start + len(s3dis_key):data_time_start].strip()

    try:
        scannet = ast.literal_eval(scannet_str)
        s3dis = ast.literal_eval(s3dis_str)
    except (ValueError, SyntaxError):
        return None

    return dict(scannet=scannet, s3dis=s3dis)


def extract_latest_val_metrics(log_path: Path) -> MetricDict:
    latest = None
    latest_epoch = None

    with log_path.open('r', encoding='utf-8', errors='ignore') as file:
        for line in file:
            parsed = _parse_val_line(line)
            if parsed is None:
                continue

            epoch = _extract_epoch(line)
            latest = parsed
            latest_epoch = epoch

    if latest is None:
        raise RuntimeError(f'No validation record found in log: {log_path}')

    return dict(epoch=latest_epoch or 0, metrics=_flatten_metrics(latest))


def _extract_epoch(line: str) -> Optional[int]:
    anchor = 'Epoch(val) ['
    start = line.find(anchor)
    if start == -1:
        return None
    start += len(anchor)
    end = line.find(']', start)
    if end == -1:
        return None
    try:
        return int(line[start:end])
    except ValueError:
        return None


def _flatten_metrics(payload: MetricDict) -> Dict[str, float]:
    return dict(
        scannet_map25=payload['scannet']['objects']['mAP_0.25'],
        scannet_map50=payload['scannet']['objects']['mAP_0.50'],
        scannet_layout_f1=payload['scannet']['layout']['f1_0.4'],
        s3dis_map25=payload['s3dis']['objects']['mAP_0.25'],
        s3dis_map50=payload['s3dis']['objects']['mAP_0.50'],
        s3dis_layout_f1=payload['s3dis']['layout']['f1_0.4'],
    )


def find_latest_log(work_dir: Path) -> Path:
    logs = sorted(work_dir.rglob('*.log'))
    if not logs:
        raise RuntimeError(f'No log file found under work dir: {work_dir}')
    return logs[-1]


def format_metric_row(name: str, epoch: int, metrics: Dict[str, float]) -> str:
    return (
        f'{name:32s} epoch={epoch:<2d} '
        f'ScanNet[{metrics["scannet_map25"]:.4f}/'
        f'{metrics["scannet_map50"]:.4f}/'
        f'{metrics["scannet_layout_f1"]:.4f}] '
        f'S3DIS[{metrics["s3dis_map25"]:.4f}/'
        f'{metrics["s3dis_map50"]:.4f}/'
        f'{metrics["s3dis_layout_f1"]:.4f}]'
    )


def load_lines(paths: Iterable[Path]) -> Dict[str, MetricDict]:
    results = {}
    for path in paths:
        results[str(path)] = extract_latest_val_metrics(path)
    return results
