import argparse
import itertools
import json
import os
import shlex
import subprocess
import sys
from pathlib import Path
from typing import Dict, Iterable, List

from geovoxel_log_utils import (
    extract_latest_val_metrics,
    find_latest_log,
    format_metric_row,
)


DEFAULT_CURRENT_STAGE_ABLATIONS = [
    dict(
        name='v1_ref',
        note='Current v1 reference with mean confidence and residual scaling.',
        voxel_feature_mode='scaled_rgb',
        backbone_in_channels=3,
        voxel_density_blend=1.0,
        point_conf_norm_mode='none',
        point_conf_norm_blend=1.0,
        point_conf_quantile_low=0.05,
        point_conf_quantile_high=0.95,
        voxel_conf_mode='mean',
        voxel_conf_power=0.5,
        voxel_conf_blend=0.5,
        voxel_conf_min=0.05,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v1_layout_safe',
        note='Softer gating to preserve more structural context for layout.',
        voxel_feature_mode='scaled_rgb',
        backbone_in_channels=3,
        voxel_density_blend=1.0,
        point_conf_norm_mode='none',
        point_conf_norm_blend=1.0,
        point_conf_quantile_low=0.05,
        point_conf_quantile_high=0.95,
        voxel_conf_mode='mean',
        voxel_conf_power=0.5,
        voxel_conf_blend=0.35,
        voxel_conf_min=0.05,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v1_lowclip',
        note='Lower confidence floor to avoid over-suppressing uncertain voxels.',
        voxel_feature_mode='scaled_rgb',
        backbone_in_channels=3,
        voxel_density_blend=1.0,
        point_conf_norm_mode='none',
        point_conf_norm_blend=1.0,
        point_conf_quantile_low=0.05,
        point_conf_quantile_high=0.95,
        voxel_conf_mode='mean',
        voxel_conf_power=0.5,
        voxel_conf_blend=0.35,
        voxel_conf_min=0.02,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v1_soft_conf',
        note='Compress confidence contrast so noisy scenes keep more baseline signal.',
        voxel_feature_mode='scaled_rgb',
        backbone_in_channels=3,
        voxel_density_blend=1.0,
        point_conf_norm_mode='none',
        point_conf_norm_blend=1.0,
        point_conf_quantile_low=0.05,
        point_conf_quantile_high=0.95,
        voxel_conf_mode='mean',
        voxel_conf_power=0.25,
        voxel_conf_blend=0.5,
        voxel_conf_min=0.02,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v1_sharp_conf',
        note='Keep the conservative blend but sharpen confidence ranking slightly.',
        voxel_feature_mode='scaled_rgb',
        backbone_in_channels=3,
        voxel_density_blend=1.0,
        point_conf_norm_mode='none',
        point_conf_norm_blend=1.0,
        point_conf_quantile_low=0.05,
        point_conf_quantile_high=0.95,
        voxel_conf_mode='mean',
        voxel_conf_power=1.0,
        voxel_conf_blend=0.35,
        voxel_conf_min=0.02,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v2lite_ref',
        note='Minimal v2-lite: keep v1 scaling and append explicit voxel_conf.',
        voxel_feature_mode='scaled_rgb_conf',
        backbone_in_channels=4,
        voxel_density_blend=1.0,
        point_conf_norm_mode='none',
        point_conf_norm_blend=1.0,
        point_conf_quantile_low=0.05,
        point_conf_quantile_high=0.95,
        voxel_conf_mode='mean',
        voxel_conf_power=0.5,
        voxel_conf_blend=0.5,
        voxel_conf_min=0.05,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v2lite_layout_safe',
        note='Explicit voxel_conf with softer scaling for layout-friendly fusion.',
        voxel_feature_mode='scaled_rgb_conf',
        backbone_in_channels=4,
        voxel_density_blend=1.0,
        point_conf_norm_mode='none',
        point_conf_norm_blend=1.0,
        point_conf_quantile_low=0.05,
        point_conf_quantile_high=0.95,
        voxel_conf_mode='mean',
        voxel_conf_power=0.5,
        voxel_conf_blend=0.35,
        voxel_conf_min=0.05,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v2lite_lowclip',
        note='Explicit voxel_conf plus lower floor to test uncertainty retention.',
        voxel_feature_mode='scaled_rgb_conf',
        backbone_in_channels=4,
        voxel_density_blend=1.0,
        point_conf_norm_mode='none',
        point_conf_norm_blend=1.0,
        point_conf_quantile_low=0.05,
        point_conf_quantile_high=0.95,
        voxel_conf_mode='mean',
        voxel_conf_power=0.5,
        voxel_conf_blend=0.35,
        voxel_conf_min=0.02,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v2p1_dualpath_ref',
        note='Keep scaled RGB for detection while preserving raw RGB for layout structure.',
        voxel_feature_mode='scaled_rgb_raw_conf',
        backbone_in_channels=7,
        voxel_density_blend=1.0,
        point_conf_norm_mode='none',
        point_conf_norm_blend=1.0,
        point_conf_quantile_low=0.05,
        point_conf_quantile_high=0.95,
        voxel_conf_mode='mean',
        voxel_conf_power=0.5,
        voxel_conf_blend=0.35,
        voxel_conf_min=0.02,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v2p1_dualpath_soft',
        note='Dual-path features plus softer confidence contrast for noisy unposed scenes.',
        voxel_feature_mode='scaled_rgb_raw_conf',
        backbone_in_channels=7,
        voxel_density_blend=1.0,
        point_conf_norm_mode='none',
        point_conf_norm_blend=1.0,
        point_conf_quantile_low=0.05,
        point_conf_quantile_high=0.95,
        voxel_conf_mode='mean',
        voxel_conf_power=0.25,
        voxel_conf_blend=0.35,
        voxel_conf_min=0.02,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v2p1_dualpath_layout',
        note='Dual-path features with weaker suppression to protect layout continuity.',
        voxel_feature_mode='scaled_rgb_raw_conf',
        backbone_in_channels=7,
        voxel_density_blend=1.0,
        point_conf_norm_mode='none',
        point_conf_norm_blend=1.0,
        point_conf_quantile_low=0.05,
        point_conf_quantile_high=0.95,
        voxel_conf_mode='mean',
        voxel_conf_power=0.5,
        voxel_conf_blend=0.25,
        voxel_conf_min=0.02,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v2p2_dualpath_pctl',
        note='Dual-path features with scene-wise percentile calibration for confidence spread.',
        voxel_feature_mode='scaled_rgb_raw_conf',
        backbone_in_channels=7,
        voxel_density_blend=1.0,
        point_conf_norm_mode='scene_percentile',
        point_conf_norm_blend=1.0,
        point_conf_quantile_low=0.05,
        point_conf_quantile_high=0.95,
        voxel_conf_mode='mean',
        voxel_conf_power=0.5,
        voxel_conf_blend=0.35,
        voxel_conf_min=0.02,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v2p2_dualpath_pctl_soft',
        note='Scene-wise percentile calibration plus softer confidence contrast.',
        voxel_feature_mode='scaled_rgb_raw_conf',
        backbone_in_channels=7,
        voxel_density_blend=1.0,
        point_conf_norm_mode='scene_percentile',
        point_conf_norm_blend=1.0,
        point_conf_quantile_low=0.05,
        point_conf_quantile_high=0.95,
        voxel_conf_mode='mean',
        voxel_conf_power=0.25,
        voxel_conf_blend=0.35,
        voxel_conf_min=0.02,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v2p2_dualpath_pctl_layout',
        note='Percentile-calibrated dual-path features with weaker suppression for layout safety.',
        voxel_feature_mode='scaled_rgb_raw_conf',
        backbone_in_channels=7,
        voxel_density_blend=1.0,
        point_conf_norm_mode='scene_percentile',
        point_conf_norm_blend=1.0,
        point_conf_quantile_low=0.05,
        point_conf_quantile_high=0.95,
        voxel_conf_mode='mean',
        voxel_conf_power=0.5,
        voxel_conf_blend=0.25,
        voxel_conf_min=0.02,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v2p3_dualpath_pctl_softblend',
        note='Percentile calibration with partial blending to keep some raw confidence ranking.',
        voxel_feature_mode='scaled_rgb_raw_conf',
        backbone_in_channels=7,
        voxel_density_blend=1.0,
        point_conf_norm_mode='scene_percentile',
        point_conf_norm_blend=0.5,
        point_conf_quantile_low=0.10,
        point_conf_quantile_high=0.90,
        voxel_conf_mode='mean',
        voxel_conf_power=0.25,
        voxel_conf_blend=0.35,
        voxel_conf_min=0.02,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v2p3_dualpath_pctl_midblend',
        note='Percentile calibration with moderate blend and less aggressive quantiles.',
        voxel_feature_mode='scaled_rgb_raw_conf',
        backbone_in_channels=7,
        voxel_density_blend=1.0,
        point_conf_norm_mode='scene_percentile',
        point_conf_norm_blend=0.65,
        point_conf_quantile_low=0.10,
        point_conf_quantile_high=0.90,
        voxel_conf_mode='mean',
        voxel_conf_power=0.25,
        voxel_conf_blend=0.35,
        voxel_conf_min=0.02,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v2p3_dualpath_layout_softblend',
        note='Layout-safe dual-path calibration with weaker voxel suppression and partial norm blend.',
        voxel_feature_mode='scaled_rgb_raw_conf',
        backbone_in_channels=7,
        voxel_density_blend=1.0,
        point_conf_norm_mode='scene_percentile',
        point_conf_norm_blend=0.5,
        point_conf_quantile_low=0.10,
        point_conf_quantile_high=0.90,
        voxel_conf_mode='mean',
        voxel_conf_power=0.25,
        voxel_conf_blend=0.25,
        voxel_conf_min=0.02,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v2p4_dualpath_balanced',
        note='A softer mid-point between softblend and midblend to reduce seed sensitivity.',
        voxel_feature_mode='scaled_rgb_raw_conf',
        backbone_in_channels=7,
        voxel_density_blend=1.0,
        point_conf_norm_mode='scene_percentile',
        point_conf_norm_blend=0.55,
        point_conf_quantile_low=0.10,
        point_conf_quantile_high=0.90,
        voxel_conf_mode='mean',
        voxel_conf_power=0.25,
        voxel_conf_blend=0.35,
        voxel_conf_min=0.02,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v2p4_dualpath_balanced_layout',
        note='Balanced calibration with slightly weaker voxel suppression to protect layout consistency.',
        voxel_feature_mode='scaled_rgb_raw_conf',
        backbone_in_channels=7,
        voxel_density_blend=1.0,
        point_conf_norm_mode='scene_percentile',
        point_conf_norm_blend=0.55,
        point_conf_quantile_low=0.10,
        point_conf_quantile_high=0.90,
        voxel_conf_mode='mean',
        voxel_conf_power=0.25,
        voxel_conf_blend=0.30,
        voxel_conf_min=0.02,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v2p5_density_soft',
        note='Add explicit voxel density on top of stable softblend to recover S3DIS strict detection.',
        voxel_feature_mode='scaled_rgb_raw_conf_count',
        backbone_in_channels=8,
        voxel_density_blend=1.0,
        point_conf_norm_mode='scene_percentile',
        point_conf_norm_blend=0.50,
        point_conf_quantile_low=0.10,
        point_conf_quantile_high=0.90,
        voxel_conf_mode='mean',
        voxel_conf_power=0.25,
        voxel_conf_blend=0.35,
        voxel_conf_min=0.02,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v2p5_density_mid',
        note='Keep the stronger ScanNet-focused blend but add voxel density for stricter S3DIS filtering.',
        voxel_feature_mode='scaled_rgb_raw_conf_count',
        backbone_in_channels=8,
        voxel_density_blend=1.0,
        point_conf_norm_mode='scene_percentile',
        point_conf_norm_blend=0.65,
        point_conf_quantile_low=0.10,
        point_conf_quantile_high=0.90,
        voxel_conf_mode='mean',
        voxel_conf_power=0.25,
        voxel_conf_blend=0.35,
        voxel_conf_min=0.02,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v2p6_density_weak_soft',
        note='Keep the v2.3 soft mainline but weaken density so ScanNet strict detection is not over-regularized.',
        voxel_feature_mode='scaled_rgb_raw_conf_count',
        backbone_in_channels=8,
        voxel_density_blend=0.35,
        point_conf_norm_mode='scene_percentile',
        point_conf_norm_blend=0.50,
        point_conf_quantile_low=0.10,
        point_conf_quantile_high=0.90,
        voxel_conf_mode='mean',
        voxel_conf_power=0.25,
        voxel_conf_blend=0.35,
        voxel_conf_min=0.02,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v2p6_density_weak_mid',
        note='Keep the stronger ScanNet-focused midblend but only weakly expose density to recover S3DIS strict detection.',
        voxel_feature_mode='scaled_rgb_raw_conf_count',
        backbone_in_channels=8,
        voxel_density_blend=0.35,
        point_conf_norm_mode='scene_percentile',
        point_conf_norm_blend=0.65,
        point_conf_quantile_low=0.10,
        point_conf_quantile_high=0.90,
        voxel_conf_mode='mean',
        voxel_conf_power=0.25,
        voxel_conf_blend=0.35,
        voxel_conf_min=0.02,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v2p7_support_reweight_mid',
        note='Keep the v2.3 midblend dual-path backbone and use voxel density only as a light aggregation prior.',
        voxel_feature_mode='scaled_rgb_raw_conf',
        backbone_in_channels=7,
        voxel_density_blend=1.0,
        voxel_support_reweight_blend=0.20,
        point_conf_norm_mode='scene_percentile',
        point_conf_norm_blend=0.65,
        point_conf_quantile_low=0.10,
        point_conf_quantile_high=0.90,
        voxel_conf_mode='mean',
        voxel_conf_power=0.25,
        voxel_conf_blend=0.35,
        voxel_conf_min=0.02,
        voxel_conf_max=1.0,
    ),
    dict(
        name='v2p8_uncertainty_agg_mid',
        note='Keep the v2.3 midblend backbone and suppress voxels whose point confidence is internally inconsistent.',
        voxel_feature_mode='scaled_rgb_raw_conf',
        backbone_in_channels=7,
        voxel_density_blend=1.0,
        voxel_uncertainty_blend=0.25,
        point_conf_norm_mode='scene_percentile',
        point_conf_norm_blend=0.65,
        point_conf_quantile_low=0.10,
        point_conf_quantile_high=0.90,
        voxel_conf_mode='mean',
        voxel_conf_power=0.25,
        voxel_conf_blend=0.35,
        voxel_conf_min=0.02,
        voxel_conf_max=1.0,
    ),
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description='Run or stage short GeoVoxel ablations before full runs.')
    parser.add_argument(
        '--base-config',
        default='configs/tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v1_smoke.py',
        help='Base config used for quick screening.')
    parser.add_argument(
        '--train-script',
        default='tools/train.py',
        help='Training entry script.')
    parser.add_argument(
        '--work-root',
        default='work_dirs/geovoxel_quick_sweep',
        help='Parent directory to store ablation runs.')
    parser.add_argument(
        '--python',
        default=sys.executable,
        help='Python executable used for launching training.')
    parser.add_argument(
        '--grid-search',
        action='store_true',
        help='Use the legacy Cartesian product instead of curated stage-wise defaults.')
    parser.add_argument(
        '--modes',
        nargs='+',
        default=['mean'],
        help='Candidate values for model.voxel_conf_mode.')
    parser.add_argument(
        '--feature-modes',
        nargs='+',
        default=[
            'scaled_rgb', 'scaled_rgb_conf', 'rgb_conf',
            'scaled_rgb_raw_conf'],
        help='Candidate values for model.voxel_feature_mode in grid search.')
    parser.add_argument(
        '--conf-norm-modes',
        nargs='+',
        default=['none'],
        help='Candidate values for model.point_conf_norm_mode.')
    parser.add_argument(
        '--conf-norm-blends',
        nargs='+',
        type=float,
        default=[1.0],
        help='Candidate values for model.point_conf_norm_blend.')
    parser.add_argument(
        '--quantile-lows',
        nargs='+',
        type=float,
        default=[0.05],
        help='Candidate values for model.point_conf_quantile_low.')
    parser.add_argument(
        '--quantile-highs',
        nargs='+',
        type=float,
        default=[0.95],
        help='Candidate values for model.point_conf_quantile_high.')
    parser.add_argument(
        '--powers',
        nargs='+',
        type=float,
        default=[0.25, 0.5, 1.0],
        help='Candidate values for model.voxel_conf_power.')
    parser.add_argument(
        '--blends',
        nargs='+',
        type=float,
        default=[0.2, 0.35, 0.5, 0.7],
        help='Candidate values for model.voxel_conf_blend.')
    parser.add_argument(
        '--mins',
        nargs='+',
        type=float,
        default=[0.0, 0.02, 0.05],
        help='Candidate values for model.voxel_conf_min.')
    parser.add_argument(
        '--maxs',
        nargs='+',
        type=float,
        default=[1.0],
        help='Candidate values for model.voxel_conf_max.')
    parser.add_argument(
        '--cfg-option',
        action='append',
        default=[],
        help='Additional cfg-options appended to every run.')
    parser.add_argument(
        '--max-runs',
        type=int,
        default=None,
        help='Limit the number of generated combinations.')
    parser.add_argument(
        '--run',
        action='store_true',
        help='Actually execute runs instead of only printing commands.')
    parser.add_argument(
        '--allow-failures',
        action='store_true',
        help='Continue the sweep when one run fails.')
    parser.add_argument(
        '--gate-ref-log',
        default=None,
        help='Reference log path used by the early gate.')
    parser.add_argument(
        '--gate-script',
        default='tools/geovoxel_early_gate.py',
        help='Gate evaluator script.')
    parser.add_argument(
        '--gate-arg',
        action='append',
        default=[],
        help='Extra arguments forwarded to the gate script.')
    parser.add_argument(
        '--manifest-name',
        default='manifest.json',
        help='Name of the saved sweep manifest.')
    return parser.parse_args()


def infer_backbone_in_channels(feature_mode: str) -> int:
    if feature_mode == 'scaled_rgb':
        return 3
    if feature_mode in {'scaled_rgb_conf', 'rgb_conf'}:
        return 4
    if feature_mode == 'scaled_rgb_raw_conf':
        return 7
    if feature_mode == 'scaled_rgb_raw_conf_count':
        return 8
    raise ValueError(f'Unsupported voxel_feature_mode={feature_mode}')


def iter_combinations(args: argparse.Namespace) -> Iterable[Dict[str, object]]:
    if not args.grid_search:
        for index, combo in enumerate(DEFAULT_CURRENT_STAGE_ABLATIONS, start=1):
            record = dict(index=index)
            record.update(combo)
            yield record
        return

    product = itertools.product(
        args.feature_modes,
        args.conf_norm_modes,
        args.conf_norm_blends,
        args.quantile_lows,
        args.quantile_highs,
        args.modes,
        args.powers,
        args.blends,
        args.mins,
        args.maxs,
    )
    for index, (
        feature_mode,
        conf_norm_mode,
        conf_norm_blend,
        quantile_low,
        quantile_high,
        mode,
        power,
        blend,
        vmin,
        vmax,
    ) in enumerate(product, start=1):
        yield dict(
            index=index,
            voxel_feature_mode=feature_mode,
            backbone_in_channels=infer_backbone_in_channels(feature_mode),
            point_conf_norm_mode=conf_norm_mode,
            point_conf_norm_blend=conf_norm_blend,
            point_conf_quantile_low=quantile_low,
            point_conf_quantile_high=quantile_high,
            voxel_conf_mode=mode,
            voxel_conf_power=power,
            voxel_conf_blend=blend,
            voxel_conf_min=vmin,
            voxel_conf_max=vmax,
        )


def short_float(value: float) -> str:
    text = f'{value:.4f}'.rstrip('0').rstrip('.')
    return text.replace('-', 'm').replace('.', 'p')


def build_experiment_name(combo: Dict[str, object]) -> str:
    if 'name' in combo:
        return str(combo['name'])
    return (
        f'feat-{combo["voxel_feature_mode"]}_'
        f'mode-{combo["voxel_conf_mode"]}_'
        f'pow-{short_float(combo["voxel_conf_power"])}_'
        f'blend-{short_float(combo["voxel_conf_blend"])}_'
        f'min-{short_float(combo["voxel_conf_min"])}_'
        f'max-{short_float(combo["voxel_conf_max"])}'
    )


def build_cfg_options(combo: Dict[str, object], extra_options: List[str]) -> List[str]:
    voxel_density_blend = combo.get('voxel_density_blend', 1.0)
    voxel_support_reweight_blend = combo.get('voxel_support_reweight_blend', 0.0)
    voxel_uncertainty_blend = combo.get('voxel_uncertainty_blend', 0.0)
    point_conf_norm_mode = combo.get('point_conf_norm_mode', 'none')
    point_conf_norm_blend = combo.get('point_conf_norm_blend', 1.0)
    point_conf_quantile_low = combo.get('point_conf_quantile_low', 0.05)
    point_conf_quantile_high = combo.get('point_conf_quantile_high', 0.95)
    options = [
        f'model.voxel_feature_mode={combo["voxel_feature_mode"]}',
        f'model.backbone.in_channels={combo["backbone_in_channels"]}',
        f'model.voxel_density_blend={voxel_density_blend}',
        f'model.voxel_support_reweight_blend={voxel_support_reweight_blend}',
        f'model.voxel_uncertainty_blend={voxel_uncertainty_blend}',
        f'model.point_conf_norm_mode={point_conf_norm_mode}',
        f'model.point_conf_norm_blend={point_conf_norm_blend}',
        f'model.point_conf_quantile_low={point_conf_quantile_low}',
        f'model.point_conf_quantile_high={point_conf_quantile_high}',
        f'model.voxel_conf_mode={combo["voxel_conf_mode"]}',
        f'model.voxel_conf_power={combo["voxel_conf_power"]}',
        f'model.voxel_conf_blend={combo["voxel_conf_blend"]}',
        f'model.voxel_conf_min={combo["voxel_conf_min"]}',
        f'model.voxel_conf_max={combo["voxel_conf_max"]}',
    ]
    options.extend(extra_options)
    return options


def build_train_command(
    args: argparse.Namespace,
    work_dir: Path,
    cfg_options: List[str],
) -> List[str]:
    command = [
        args.python,
        args.train_script,
        args.base_config,
        '--work-dir',
        str(work_dir),
    ]
    if cfg_options:
        command.append('--cfg-options')
        command.extend(cfg_options)
    return command


def run_command(command: List[str], env: Dict[str, str]) -> int:
    process = subprocess.run(command, env=env, check=False)
    return process.returncode


def build_env(project_root: Path) -> Dict[str, str]:
    env = os.environ.copy()
    current = env.get('PYTHONPATH', '')
    pieces = [str(project_root)]
    if current:
        pieces.append(current)
    env['PYTHONPATH'] = os.pathsep.join(pieces)
    return env


def evaluate_gate(
    args: argparse.Namespace,
    log_path: Path,
    env: Dict[str, str],
) -> subprocess.CompletedProcess:
    command = [args.python, args.gate_script, '--log', str(log_path)]
    if args.gate_ref_log:
        command.extend(['--ref-log', args.gate_ref_log])
    command.extend(args.gate_arg)
    return subprocess.run(command, env=env, check=False, capture_output=True, text=True)


def main() -> None:
    args = parse_args()
    project_root = Path(__file__).resolve().parents[1]
    work_root = project_root / args.work_root
    work_root.mkdir(parents=True, exist_ok=True)

    combos = list(iter_combinations(args))
    if args.max_runs is not None:
        combos = combos[:args.max_runs]

    manifest = []
    env = build_env(project_root)

    for combo in combos:
        exp_name = build_experiment_name(combo)
        work_dir = work_root / exp_name
        cfg_options = build_cfg_options(combo, args.cfg_option)
        command = build_train_command(args, work_dir, cfg_options)
        record = dict(
            name=exp_name,
            combo=combo,
            work_dir=str(work_dir),
            cfg_options=cfg_options,
            command=command,
        )
        if 'note' in combo:
            record['note'] = combo['note']
        manifest.append(record)

    manifest_path = work_root / args.manifest_name
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding='utf-8')

    print(f'Sweep manifest saved to: {manifest_path}')
    print(f'Total candidates: {len(manifest)}')

    for record in manifest:
        cmd_text = ' '.join(shlex.quote(part) for part in record['command'])
        print(f'- {record["name"]}: {cmd_text}')
        if 'note' in record:
            print(f'    note: {record["note"]}')

    if not args.run:
        return

    print('\nLaunching quick sweep...')
    summaries = []
    for record in manifest:
        print(f'\n[RUN] {record["name"]}')
        returncode = run_command(record['command'], env)
        record['returncode'] = returncode
        if returncode != 0:
            print(f'  -> training failed with code {returncode}')
            if not args.allow_failures:
                raise SystemExit(returncode)
            continue

        log_path = find_latest_log(Path(record['work_dir']))
        result = extract_latest_val_metrics(log_path)
        record['log_path'] = str(log_path)
        record['epoch'] = result['epoch']
        record['metrics'] = result['metrics']
        summaries.append(record)
        print('  -> ' + format_metric_row(
            record['name'], record['epoch'], record['metrics']))

        if args.gate_ref_log or args.gate_arg:
            gate = evaluate_gate(args, log_path, env)
            record['gate_returncode'] = gate.returncode
            record['gate_stdout'] = gate.stdout
            record['gate_stderr'] = gate.stderr
            print(gate.stdout.strip())
            if gate.stderr.strip():
                print(gate.stderr.strip())

        manifest_path.write_text(json.dumps(manifest, indent=2), encoding='utf-8')

    if summaries:
        print('\nQuick sweep summary:')
        for record in summaries:
            print('  ' + format_metric_row(
                record['name'], record['epoch'], record['metrics']))


if __name__ == '__main__':
    main()
