import argparse
from pathlib import Path
from typing import Dict, List, Tuple

from geovoxel_log_utils import extract_latest_val_metrics, find_latest_log


CURATED_RUNS: List[Tuple[str, str, str]] = [
    ('baseline', 'v1_ref', 'work_dirs/geovoxel_quick_sweep/v1_ref'),
    ('explicit_conf', 'v2lite_lowclip', 'work_dirs/geovoxel_quick_sweep/v2lite_lowclip'),
    ('dual_path', 'v2p2_pctl_soft', 'work_dirs/geovoxel_quick_sweep/v2p2_dualpath_pctl_soft'),
    ('dual_path', 'v2p3_softblend', 'work_dirs/geovoxel_quick_sweep/v2p3_dualpath_pctl_softblend'),
    ('dual_path', 'v2p3_midblend', 'work_dirs/geovoxel_quick_sweep/v2p3_dualpath_pctl_midblend'),
    ('seed_replay', 'v2p3_mid_seed3407', 'work_dirs/geovoxel_quick_sweep/v2p3_midblend_seed3407_2epoch'),
    ('seed_replay', 'v2p3_soft_seed3407', 'work_dirs/geovoxel_quick_sweep/v2p3_softblend_seed3407_2epoch'),
    ('balanced', 'v2p4_balanced', 'work_dirs/geovoxel_quick_sweep/v2p4_dualpath_balanced'),
    ('balanced', 'v2p4_balanced_layout', 'work_dirs/geovoxel_quick_sweep/v2p4_dualpath_balanced_layout'),
    ('density', 'v2p5_density_soft', 'work_dirs/geovoxel_quick_sweep/v2p5_density_soft'),
    ('density', 'v2p5_density_mid', 'work_dirs/geovoxel_quick_sweep/v2p5_density_mid'),
    ('density_weak', 'v2p6_density_weak_soft', 'work_dirs/geovoxel_quick_sweep/v2p6_density_weak_soft'),
    ('density_weak', 'v2p6_density_weak_mid', 'work_dirs/geovoxel_quick_sweep/v2p6_density_weak_mid'),
    ('density_sweep', 'v2p6_mid_d015', 'work_dirs/geovoxel_quick_sweep/v2p6_mid_d015'),
    ('density_sweep', 'v2p6_mid_d020', 'work_dirs/geovoxel_quick_sweep/v2p6_mid_d020'),
    ('density_sweep', 'v2p6_mid_d025', 'work_dirs/geovoxel_quick_sweep/v2p6_mid_d025'),
    ('density_sweep', 'v2p6_mid_d030', 'work_dirs/geovoxel_quick_sweep/v2p6_mid_d030'),
    ('support_reweight', 'v2p7_support_reweight_mid', 'work_dirs/geovoxel_quick_sweep/v2p7_support_reweight_mid'),
    ('uncertainty_agg', 'v2p8_uncertainty_agg_mid', 'work_dirs/geovoxel_quick_sweep/v2p8_uncertainty_agg_mid'),
    ('short_run', 'v2p3_mid_2epoch', 'work_dirs/geovoxel_quick_sweep/v2p3_midblend_2epoch'),
    ('short_run', 'v2p3_mid_4epoch', 'work_dirs/geovoxel_quick_sweep/v2p3_midblend_4epoch'),
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description='Summarize Stage-2 GeoVoxel runs into a markdown table.')
    parser.add_argument(
        '--project-root',
        default='.',
        help='Recognition project root.')
    parser.add_argument(
        '--reference-label',
        default='v2lite_lowclip',
        help='Reference label used for delta columns.')
    parser.add_argument(
        '--output',
        default='analysis/stage2_geovoxel_progress_20260425.md',
        help='Markdown output path relative to project root.')
    return parser.parse_args()


def resolve_log(project_root: Path, run_path: str) -> Path:
    candidate = project_root / run_path
    if candidate.is_file():
        return candidate
    return find_latest_log(candidate)


def collect_rows(project_root: Path) -> List[Dict[str, object]]:
    rows = []
    for stage, label, run_path in CURATED_RUNS:
        log_path = resolve_log(project_root, run_path)
        result = extract_latest_val_metrics(log_path)
        row = dict(
            stage=stage,
            label=label,
            epoch=result['epoch'],
            log_path=log_path,
        )
        row.update(result['metrics'])
        rows.append(row)
    return rows


def format_delta(value: float) -> str:
    if value > 0:
        return f'+{value:.4f}'
    return f'{value:.4f}'


def build_markdown(rows: List[Dict[str, object]], reference_label: str) -> str:
    reference = None
    for row in rows:
        if row['label'] == reference_label:
            reference = row
            break
    if reference is None:
        raise ValueError(f'Cannot find reference label: {reference_label}')

    lines = [
        '# Stage-2 GeoVoxel Progress',
        '',
        f'- Reference: `{reference_label}`',
        f'- Generated from {len(rows)} runs',
        '',
        '| Stage | Label | Epoch | ScanNet (0.25/0.50/F1) | S3DIS (0.25/0.50/F1) | Delta vs ref (SN50 / S350 / S3F1) |',
        '| --- | --- | ---: | --- | --- | --- |',
    ]
    for row in rows:
        sn = (
            f'{row["scannet_map25"]:.4f}/'
            f'{row["scannet_map50"]:.4f}/'
            f'{row["scannet_layout_f1"]:.4f}'
        )
        s3 = (
            f'{row["s3dis_map25"]:.4f}/'
            f'{row["s3dis_map50"]:.4f}/'
            f'{row["s3dis_layout_f1"]:.4f}'
        )
        delta = (
            f'{format_delta(row["scannet_map50"] - reference["scannet_map50"])} / '
            f'{format_delta(row["s3dis_map50"] - reference["s3dis_map50"])} / '
            f'{format_delta(row["s3dis_layout_f1"] - reference["s3dis_layout_f1"])}'
        )
        lines.append(
            f'| {row["stage"]} | {row["label"]} | {row["epoch"]} | {sn} | {s3} | {delta} |')

    lines.extend([
        '',
        '## Takeaways',
        '',
        '- `v2lite_lowclip` 仍然是当前 S3DIS strict detection 的主要参考线。',
        '- `v2p2_pctl_soft` 说明 percentile calibration 能抬 ScanNet strict detection，但代价是 S3DIS strict detection 偏弱。',
        '- `v2p3_softblend` / `v2p3_midblend` 说明更保守的 calibration 确实能把 ScanNet strict detection 稳定到接近 `0.195` 附近。',
        '- fixed-seed 复验里 `softblend` 与 `midblend` 非常接近，说明当前主矛盾已经从“有没有机制”转成“增益是否稳定可复现”。',
        '- `v2p4` 用 `0.55` 的 norm blend 继续测试 soft/mid 之间的折中点，重点看是否能降低 seed 敏感性而不是追单次峰值。',
        '- `v2p5_density_*` 证明显式 density 通道能补一部分 S3DIS strict detection，但会压低 ScanNet strict detection，需要继续做弱融合而不是强注入。',
        '- `v2p6_density_weak_mid` 基本把 ScanNet strict detection 拉回到 `v2p3_softblend` 附近，但没有稳定保住 `v2p5` 的 S3DIS strict detection 增益。',
        '- `v2p6_density_weak_soft` 只保住了很小的 S3DIS strict detection 补偿，且 ScanNet / layout 都不如预期，说明 density 弱融合的强度窗口还比较窄。',
        '- 进一步对 `v2p6_density_weak_mid` 做 `0.15 / 0.20 / 0.25 / 0.30` 的 density sweep 后，没有出现同时优于 `v2p3_midblend` 的点，说明显式 density 通道目前更像是 trade-off 旋钮，而不是稳定增益来源。',
        '- 这轮 sweep 里 `v2p6_mid_d015` 是最接近可用的折中点，但也只是把 ScanNet `mAP@0.50` 维持在 `0.1969`，S3DIS `mAP@0.50` 仅 `0.0225`，没有形成值得继续推进 full-run 的新主线。',
        '- `v2p7_support_reweight_mid` 进一步验证了 density 即便不进 backbone、只做轻量 aggregation reweight，也还没有带来净增益，说明当前主矛盾更可能在 uncertainty/layout consistency，而不是 support 先验本身。',
        '- `v2p8_uncertainty_agg_mid` 说明简单的体素内 confidence variance 惩罚会进一步压低 strict detection，当前说明“估计不确定性”本身没错，但这个版本的 uncertainty proxy 过于粗糙，容易把真实边界/稀疏目标也一起抑制。',
        '- `v2p3_mid_4epoch` 没有把 ScanNet `mAP@0.50` 稳定维持在 `0.20+`，因此现阶段不建议直接推进 full-run。',
        '',
        '## Logs',
        '',
    ])
    for row in rows:
        lines.append(f'- `{row["label"]}`: `{row["log_path"]}`')
    lines.append('')
    return '\n'.join(lines)


def main() -> None:
    args = parse_args()
    project_root = Path(args.project_root).resolve()
    rows = collect_rows(project_root)
    content = build_markdown(rows, args.reference_label)
    output_path = project_root / args.output
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(content, encoding='utf-8')
    print(f'Summary saved to: {output_path}')


if __name__ == '__main__':
    main()
