import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Tuple

from geovoxel_log_utils import (_extract_epoch, _flatten_metrics,
                                _parse_val_line, extract_latest_val_metrics)


DEFAULT_RUN_SPECS = [
    (
        'stage1_safe',
        'configs/tun3d_1xb16_scannet_s3dis_unposed_geoconf_v1_nan_debug_resume10.py',
        'work_dirs/tun3d_unposed_geoconf_v1_nan_debug_resume10/epoch_11.pth',
    ),
    (
        'v2p3_midblend',
        'work_dirs/geovoxel_quick_sweep/v2p3_dualpath_pctl_midblend/'
        'tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v2_3_smoke.py',
        'work_dirs/geovoxel_quick_sweep/v2p3_dualpath_pctl_midblend/epoch_1.pth',
    ),
    (
        'v2p9a_smoke_noamp',
        'work_dirs/tun3d_unposed_geovoxel_v2_9a_smoke_noamp/'
        'tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v2_9a_smoke.py',
        'work_dirs/tun3d_unposed_geovoxel_v2_9a_smoke_noamp/epoch_1.pth',
    ),
    (
        'v2p9c_epoch3',
        'work_dirs/tun3d_unposed_geovoxel_v2_9c_noamp/'
        'tun3d_1xb16_scannet_s3dis_unposed_geovoxel_v2_9c.py',
        'work_dirs/tun3d_unposed_geovoxel_v2_9c_noamp/epoch_3.pth',
    ),
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description='v3.0 diagnose runner for TUN3D GeoVoxel experiments.')
    parser.add_argument(
        '--project-root',
        type=Path,
        default=Path(__file__).resolve().parents[2],
        help='TUN3D project root.')
    parser.add_argument(
        '--output-dir',
        type=Path,
        default=Path('work_dirs/v3_0_diagnose'),
        help='Diagnosis output directory relative to recognition root.')
    parser.add_argument(
        '--run-spec',
        action='append',
        default=[],
        help='Run spec formatted as label|config_path|checkpoint_path. '
        'If omitted, use curated defaults.')
    parser.add_argument(
        '--anchor-label',
        default='v2p3_midblend',
        help='Reference label used for delta comparisons.')
    parser.add_argument(
        '--test-num-workers',
        type=int,
        default=0,
        help='Override test dataloader num_workers during diagnose runs.')
    parser.add_argument(
        '--scene-topk',
        type=int,
        default=10,
        help='How many scene examples to keep in compare markdown.')
    parser.add_argument(
        '--skip-eval',
        action='store_true',
        help='Skip model evaluation and only rebuild compare reports from existing outputs.')
    parser.add_argument(
        '--force',
        action='store_true',
        help='Re-run even if summary files already exist.')
    parser.add_argument(
        '--keep-going',
        action='store_true',
        help='Continue remaining runs if one evaluation fails.')
    parser.add_argument(
        '--run-voxel-diag',
        action='store_true',
        help='Also execute voxel-level diagnostics after the compare runs.')
    parser.add_argument(
        '--voxel-output-dir',
        type=Path,
        default=None,
        help='Optional output directory for voxel diagnostics.')
    parser.add_argument(
        '--voxel-datasets',
        nargs='+',
        default=['scannet', 's3dis'],
        choices=['scannet', 's3dis'],
        help='Datasets for voxel diagnostics.')
    parser.add_argument(
        '--voxel-points-subdir',
        default='points_unposed_geoconf_v2',
        help='Points subdir for voxel diagnostics.')
    parser.add_argument(
        '--voxel-max-scenes-per-dataset',
        type=int,
        default=50,
        help='Scene cap for voxel diagnostics; use -1 for full.')
    parser.add_argument(
        '--voxel-skip-csv',
        action='store_true',
        help='Skip full voxel csv dump in voxel diagnostics.')
    return parser.parse_args()


def parse_run_specs(raw_specs: List[str]) -> List[Tuple[str, str, str]]:
    if not raw_specs:
        return list(DEFAULT_RUN_SPECS)

    run_specs = []
    for raw_spec in raw_specs:
        parts = raw_spec.split('|')
        if len(parts) != 3:
            raise ValueError(
                f'Invalid run spec: {raw_spec}. Expected label|config|checkpoint.')
        run_specs.append((parts[0].strip(), parts[1].strip(), parts[2].strip()))
    return run_specs


def ensure_path(base: Path, maybe_relative: str) -> Path:
    path = Path(maybe_relative)
    if path.is_absolute():
        return path
    return (base / path).resolve()


def extract_val_history(log_path: Path) -> List[Dict[str, object]]:
    history = []
    with log_path.open('r', encoding='utf-8', errors='ignore') as file:
        for line in file:
            if 'Epoch(val)' not in line or 'scannet:' not in line or 's3dis:' not in line:
                continue
            parsed = _parse_val_line(line)
            if parsed is None:
                continue
            epoch = _extract_epoch(line) or 0
            flat = _flatten_metrics(parsed)
            flat['epoch'] = epoch
            history.append(flat)
    return history


def to_builtin(value):
    if isinstance(value, dict):
        return {str(k): to_builtin(v) for k, v in value.items()}
    if isinstance(value, list):
        return [to_builtin(v) for v in value]
    return value


def run_single_eval(recognition_root: Path,
                    label: str,
                    config_path: Path,
                    checkpoint_path: Path,
                    eval_root: Path,
                    diagnose_dir: Path,
                    test_num_workers: int) -> Path:
    eval_root.mkdir(parents=True, exist_ok=True)
    diagnose_dir.mkdir(parents=True, exist_ok=True)
    log_path = eval_root / f'{label}_test.log'
    cmd = [
        sys.executable,
        'tools/test.py',
        str(config_path),
        str(checkpoint_path),
        '--work-dir',
        str(eval_root),
        '--cfg-options',
        f'test_evaluator.diagnose_dir={diagnose_dir}',
        f'test_evaluator.diagnose_tag={label}',
        f'test_dataloader.num_workers={test_num_workers}',
        f'val_dataloader.num_workers={test_num_workers}',
    ]
    with log_path.open('w', encoding='utf-8') as file:
        subprocess.run(
            cmd,
            cwd=recognition_root,
            stdout=file,
            stderr=subprocess.STDOUT,
            check=True)
    return log_path


def load_run_payload(diagnose_dir: Path, log_path: Path) -> Dict[str, object]:
    summary = json.loads((diagnose_dir / 'summary_metrics.json').read_text(encoding='utf-8'))
    datasets = {}
    for dataset_dir in sorted(path for path in diagnose_dir.iterdir() if path.is_dir()):
        metrics_path = dataset_dir / 'metrics.json'
        class_path = dataset_dir / 'class_metrics.json'
        scene_path = dataset_dir / 'scene_metrics.json'
        if not metrics_path.exists():
            continue
        datasets[dataset_dir.name] = dict(
            metrics=json.loads(metrics_path.read_text(encoding='utf-8')),
            class_metrics=json.loads(class_path.read_text(encoding='utf-8')),
            scene_metrics=json.loads(scene_path.read_text(encoding='utf-8')),
        )
    history = extract_val_history(log_path) if log_path.exists() else []
    return dict(summary=summary, datasets=datasets, history=history)


def metric_triplet(run_payload: Dict[str, object], dataset: str) -> Tuple[float, float, float]:
    metrics = run_payload['datasets'][dataset]['metrics']
    return (
        float(metrics['objects']['mAP_0.25']),
        float(metrics['objects']['mAP_0.50']),
        float(metrics['layout']['f1_0.4']),
    )


def build_scene_index(scene_metrics: List[dict]) -> Dict[str, dict]:
    return {scene['scene_id']: scene for scene in scene_metrics}


def format_metric(value: float) -> str:
    return f'{value:.4f}'


def format_delta(value: float) -> str:
    if value > 0:
        return f'+{value:.4f}'
    return f'{value:.4f}'


def top_class_deltas(anchor_classes: Dict[str, dict],
                     current_classes: Dict[str, dict],
                     metric_key: str,
                     topk: int) -> List[Tuple[str, float, float, float]]:
    rows = []
    for class_name in sorted(set(anchor_classes.keys()) | set(current_classes.keys())):
        anchor_value = float(anchor_classes.get(class_name, {}).get(metric_key, 0.0))
        current_value = float(current_classes.get(class_name, {}).get(metric_key, 0.0))
        rows.append((class_name, anchor_value, current_value, current_value - anchor_value))
    rows.sort(key=lambda row: row[3], reverse=True)
    return rows[:topk]


def scene_delta_rows(anchor_scenes: Dict[str, dict],
                     current_scenes: Dict[str, dict],
                     topk: int) -> Dict[str, List[Tuple[str, float, float, float, float]]]:
    rows = []
    for scene_id, anchor_scene in anchor_scenes.items():
        current_scene = current_scenes.get(scene_id)
        if current_scene is None:
            continue
        anchor_layout = float(anchor_scene['layout'].get('0.4', {}).get('f1', 0.0))
        current_layout = float(current_scene['layout'].get('0.4', {}).get('f1', 0.0))
        anchor_det = float(anchor_scene['detection'].get('0.5', {}).get('f1', 0.0))
        current_det = float(current_scene['detection'].get('0.5', {}).get('f1', 0.0))
        rows.append((
            scene_id,
            current_layout - anchor_layout,
            current_det - anchor_det,
            current_layout,
            current_det,
        ))

    by_layout_gain = sorted(rows, key=lambda row: (row[1], row[2]), reverse=True)[:topk]
    by_det_drop = sorted(rows, key=lambda row: (row[2], row[1]))[:topk]
    return dict(layout_gain=by_layout_gain, det_drop=by_det_drop)


def build_compare_markdown(run_payloads: Dict[str, Dict[str, object]],
                           anchor_label: str,
                           scene_topk: int) -> str:
    if anchor_label not in run_payloads:
        raise ValueError(f'Anchor label {anchor_label} not found in run payloads.')

    anchor_payload = run_payloads[anchor_label]
    lines = [
        '# v3.0 Diagnose Report',
        '',
        f'- Anchor: `{anchor_label}`',
        f'- Runs: {", ".join(f"`{label}`" for label in run_payloads.keys())}',
        '',
        '## Summary',
        '',
        '| Run | ScanNet 0.25 | ScanNet 0.50 | ScanNet F1 | S3DIS 0.25 | S3DIS 0.50 | S3DIS F1 |',
        '| --- | ---: | ---: | ---: | ---: | ---: | ---: |',
    ]
    for label, payload in run_payloads.items():
        sn25, sn50, snf1 = metric_triplet(payload, 'scannet')
        s325, s350, s3f1 = metric_triplet(payload, 's3dis')
        lines.append(
            f'| {label} | {format_metric(sn25)} | {format_metric(sn50)} | '
            f'{format_metric(snf1)} | {format_metric(s325)} | '
            f'{format_metric(s350)} | {format_metric(s3f1)} |')

    for dataset in ('scannet', 's3dis'):
        lines.extend([
            '',
            f'## {dataset} Class Delta vs `{anchor_label}`',
            '',
        ])
        anchor_classes = anchor_payload['datasets'][dataset]['class_metrics']
        for label, payload in run_payloads.items():
            if label == anchor_label:
                continue
            lines.append(f'### {label}')
            lines.append('')
            lines.append('| Class | Anchor AP@0.50 | Current AP@0.50 | Delta |')
            lines.append('| --- | ---: | ---: | ---: |')
            for class_name, anchor_value, current_value, delta in top_class_deltas(
                    anchor_classes,
                    payload['datasets'][dataset]['class_metrics'],
                    'AP_0.50',
                    topk=scene_topk):
                lines.append(
                    f'| {class_name} | {format_metric(anchor_value)} | '
                    f'{format_metric(current_value)} | {format_delta(delta)} |')
            lines.append('')

    for dataset in ('scannet', 's3dis'):
        anchor_scenes = build_scene_index(anchor_payload['datasets'][dataset]['scene_metrics'])
        lines.extend([
            '',
            f'## {dataset} Scene Delta vs `{anchor_label}`',
            '',
        ])
        for label, payload in run_payloads.items():
            if label == anchor_label:
                continue
            current_scenes = build_scene_index(payload['datasets'][dataset]['scene_metrics'])
            delta_rows = scene_delta_rows(anchor_scenes, current_scenes, scene_topk)
            lines.append(f'### {label} - layout gain')
            lines.append('')
            lines.append('| Scene | Layout F1 Delta | Det F1@0.50 Delta | Current Layout F1 | Current Det F1@0.50 |')
            lines.append('| --- | ---: | ---: | ---: | ---: |')
            for scene_id, layout_delta, det_delta, cur_layout, cur_det in delta_rows['layout_gain']:
                lines.append(
                    f'| {scene_id} | {format_delta(layout_delta)} | {format_delta(det_delta)} | '
                    f'{format_metric(cur_layout)} | {format_metric(cur_det)} |')
            lines.append('')

            lines.append(f'### {label} - detection drop')
            lines.append('')
            lines.append('| Scene | Layout F1 Delta | Det F1@0.50 Delta | Current Layout F1 | Current Det F1@0.50 |')
            lines.append('| --- | ---: | ---: | ---: | ---: |')
            for scene_id, layout_delta, det_delta, cur_layout, cur_det in delta_rows['det_drop']:
                lines.append(
                    f'| {scene_id} | {format_delta(layout_delta)} | {format_delta(det_delta)} | '
                    f'{format_metric(cur_layout)} | {format_metric(cur_det)} |')
            lines.append('')

    return '\n'.join(lines)


def run_voxel_diagnostics(args: argparse.Namespace, recognition_root: Path, output_dir: Path) -> None:
    voxel_output_dir = args.voxel_output_dir
    if voxel_output_dir is None:
        voxel_output_dir = output_dir / 'voxel_diagnostics'
    else:
        voxel_output_dir = ensure_path(recognition_root, str(voxel_output_dir))
    voxel_output_dir.mkdir(parents=True, exist_ok=True)

    cmd = [
        sys.executable,
        'tools/geovoxel_voxel_diagnostics.py',
        '--project-root',
        str(args.project_root),
        '--output-dir',
        str(voxel_output_dir),
        '--points-subdir',
        args.voxel_points_subdir,
        '--max-scenes-per-dataset',
        str(args.voxel_max_scenes_per_dataset),
        '--datasets',
        *args.voxel_datasets,
    ]
    if args.voxel_skip_csv:
        cmd.append('--skip-voxel-csv')
    subprocess.run(cmd, cwd=recognition_root, check=True)


def main() -> None:
    args = parse_args()
    project_root = args.project_root.resolve()
    recognition_root = project_root / 'recognition'
    output_dir = ensure_path(recognition_root, str(args.output_dir))
    output_dir.mkdir(parents=True, exist_ok=True)

    run_specs = parse_run_specs(args.run_spec)
    run_payloads = {}
    compare_manifest = []

    for label, config_str, checkpoint_str in run_specs:
        config_path = ensure_path(recognition_root, config_str)
        checkpoint_path = ensure_path(recognition_root, checkpoint_str)
        diagnose_dir = output_dir / 'runs' / label
        eval_root = output_dir / 'eval_logs' / label
        summary_path = diagnose_dir / 'summary_metrics.json'
        eval_log = eval_root / f'{label}_test.log'

        try:
            if not args.skip_eval and (args.force or not summary_path.exists()):
                print(f'[v3.0-diagnose] evaluating {label}')
                run_single_eval(
                    recognition_root=recognition_root,
                    label=label,
                    config_path=config_path,
                    checkpoint_path=checkpoint_path,
                    eval_root=eval_root,
                    diagnose_dir=diagnose_dir,
                    test_num_workers=args.test_num_workers)
            else:
                print(f'[v3.0-diagnose] reuse existing outputs for {label}')

            run_payloads[label] = load_run_payload(diagnose_dir, eval_log)
            compare_manifest.append(dict(
                label=label,
                config=str(config_path),
                checkpoint=str(checkpoint_path),
                diagnose_dir=str(diagnose_dir),
                eval_log=str(eval_log)))
        except Exception as exc:  # pragma: no cover - best effort orchestration
            if not args.keep_going:
                raise
            print(f'[v3.0-diagnose] failed on {label}: {exc}')

    if not run_payloads:
        raise RuntimeError('No run payloads were collected.')

    manifest_path = output_dir / 'compare_manifest.json'
    manifest_path.write_text(
        json.dumps(to_builtin(compare_manifest), indent=2),
        encoding='utf-8')

    compare_report = build_compare_markdown(
        run_payloads=run_payloads,
        anchor_label=args.anchor_label,
        scene_topk=args.scene_topk)
    compare_path = output_dir / 'compare_report.md'
    compare_path.write_text(compare_report, encoding='utf-8')

    payload_path = output_dir / 'compare_payload.json'
    payload_path.write_text(
        json.dumps(to_builtin(run_payloads), indent=2),
        encoding='utf-8')

    if args.run_voxel_diag:
        print('[v3.0-diagnose] running voxel diagnostics')
        run_voxel_diagnostics(args, recognition_root, output_dir)

    print(f'[v3.0-diagnose] report saved to: {compare_path}')


if __name__ == '__main__':
    main()
