import argparse
import csv
import json
import pickle
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import numpy as np


DEFAULT_ROLE_NAMES = (
    'object_boundary',
    'object_interior',
    'layout_surface',
    'background',
)


class OnlineStat:
    def __init__(self) -> None:
        self.count = 0
        self.total = 0.0
        self.total_sq = 0.0
        self.min_value = float('inf')
        self.max_value = float('-inf')

    def update(self, values: np.ndarray) -> None:
        if values.size == 0:
            return
        values64 = values.astype(np.float64, copy=False)
        self.count += int(values64.size)
        self.total += float(values64.sum())
        self.total_sq += float(np.square(values64).sum())
        self.min_value = min(self.min_value, float(values64.min()))
        self.max_value = max(self.max_value, float(values64.max()))

    def to_dict(self) -> Dict[str, Optional[float]]:
        if self.count == 0:
            return dict(
                count=0,
                mean=None,
                std=None,
                min=None,
                max=None,
            )
        mean = self.total / self.count
        var = max(self.total_sq / self.count - mean * mean, 0.0)
        return dict(
            count=self.count,
            mean=mean,
            std=var ** 0.5,
            min=self.min_value,
            max=self.max_value,
        )


class SummaryBucket:
    def __init__(self) -> None:
        self.metrics = {
            'point_count': OnlineStat(),
            'conf_mean': OnlineStat(),
            'conf_var': OnlineStat(),
            'conf_min': OnlineStat(),
            'conf_max': OnlineStat(),
            'voxel_scale': OnlineStat(),
            'support_scale': OnlineStat(),
            'uncertainty_scale': OnlineStat(),
            'object_ratio': OnlineStat(),
            'boundary_ratio': OnlineStat(),
            'layout_ratio': OnlineStat(),
        }
        self.num_voxels = 0

    def update(self, rows: Dict[str, np.ndarray]) -> None:
        num_rows = int(rows['point_count'].shape[0])
        self.num_voxels += num_rows
        for metric_name, stat in self.metrics.items():
            stat.update(rows[metric_name])

    def to_dict(self) -> Dict[str, object]:
        return dict(
            num_voxels=self.num_voxels,
            metrics={name: stat.to_dict() for name, stat in self.metrics.items()},
        )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description='Voxel-level diagnostic script for TUN3D GeoVoxel experiments.')
    parser.add_argument(
        '--project-root',
        type=Path,
        default=Path(__file__).resolve().parents[2],
        help='TUN3D project root. Defaults to the current repository root.')
    parser.add_argument(
        '--datasets',
        nargs='+',
        default=['scannet', 's3dis'],
        choices=['scannet', 's3dis'],
        help='Datasets to diagnose.')
    parser.add_argument(
        '--voxel-size',
        type=float,
        default=0.01,
        help='Voxel size used by the GeoVoxel detector.')
    parser.add_argument(
        '--points-subdir',
        default='points_unposed_geoconf_v2',
        help='Point-cloud directory under each dataset root.')
    parser.add_argument(
        '--max-scenes-per-dataset',
        type=int,
        default=-1,
        help='Only process the first N scenes from each dataset. Use -1 for all.')
    parser.add_argument(
        '--boundary-ratio',
        type=float,
        default=0.15,
        help='Relative margin used to split bbox interior/boundary.')
    parser.add_argument(
        '--boundary-min',
        type=float,
        default=0.03,
        help='Absolute minimum boundary margin in meters.')
    parser.add_argument(
        '--layout-dist-thr',
        type=float,
        default=0.05,
        help='Distance threshold used to match reconstructed points to GT layout quads.')
    parser.add_argument(
        '--layout-span-pad',
        type=float,
        default=0.05,
        help='Extra padding on in-plane quad extent matching.')
    parser.add_argument(
        '--point-conf-norm-mode',
        default='scene_percentile',
        choices=['none', 'scene_minmax', 'scene_percentile'],
        help='Point-confidence normalization mode from the detector config.')
    parser.add_argument(
        '--point-conf-norm-blend',
        type=float,
        default=0.65,
        help='Blend factor for point-confidence normalization.')
    parser.add_argument(
        '--point-conf-quantile-low',
        type=float,
        default=0.10,
        help='Lower quantile for scene_percentile normalization.')
    parser.add_argument(
        '--point-conf-quantile-high',
        type=float,
        default=0.90,
        help='Upper quantile for scene_percentile normalization.')
    parser.add_argument(
        '--point-conf-eps',
        type=float,
        default=1e-6,
        help='Numerical epsilon used in confidence normalization.')
    parser.add_argument(
        '--voxel-conf-mode',
        default='mean',
        choices=['sum', 'mean'],
        help='Voxel confidence aggregation mode.')
    parser.add_argument(
        '--voxel-conf-power',
        type=float,
        default=0.25,
        help='Power used in voxel_scale.')
    parser.add_argument(
        '--voxel-conf-blend',
        type=float,
        default=0.35,
        help='Blend used in confidence-aware voxel scaling.')
    parser.add_argument(
        '--voxel-conf-min',
        type=float,
        default=0.02,
        help='Lower clamp for point/voxel confidence.')
    parser.add_argument(
        '--voxel-conf-max',
        type=float,
        default=1.0,
        help='Upper clamp for point/voxel confidence.')
    parser.add_argument(
        '--voxel-support-reweight-blend',
        type=float,
        default=0.20,
        help='Blend used by support reweight (v2.7-like).')
    parser.add_argument(
        '--voxel-uncertainty-blend',
        type=float,
        default=0.25,
        help='Blend used by uncertainty penalty (v2.8-like).')
    parser.add_argument(
        '--output-dir',
        type=Path,
        default=Path('work_dirs/geovoxel_voxel_diagnostics'),
        help='Directory for CSV/JSON/Markdown outputs.')
    parser.add_argument(
        '--skip-voxel-csv',
        action='store_true',
        help='Skip writing the full voxel-level CSV if only summaries are needed.')
    return parser.parse_args()


def normalize_voxel_density(voxel_count: np.ndarray) -> np.ndarray:
    voxel_count = voxel_count.astype(np.float32, copy=False)
    max_count = float(np.max(voxel_count))
    denom = np.log1p(max(max_count, 1.0))
    if denom <= 0.0:
        return np.ones_like(voxel_count, dtype=np.float32)
    return np.log1p(voxel_count) / denom


def normalize_point_confidence(confidence: np.ndarray, args: argparse.Namespace) -> np.ndarray:
    if args.point_conf_norm_mode == 'none':
        return confidence.astype(np.float32, copy=False)

    values = confidence.astype(np.float32, copy=False)
    if args.point_conf_norm_mode == 'scene_minmax':
        lower = float(values.min())
        upper = float(values.max())
    else:
        lower = float(np.quantile(values, args.point_conf_quantile_low))
        upper = float(np.quantile(values, args.point_conf_quantile_high))

    scale = max(upper - lower, args.point_conf_eps)
    normalized = np.clip((values - lower) / scale, 0.0, 1.0)
    return (
        (1.0 - args.point_conf_norm_blend) * values +
        args.point_conf_norm_blend * normalized
    ).astype(np.float32, copy=False)


def load_info_list(info_path: Path) -> List[dict]:
    with info_path.open('rb') as f:
        info = pickle.load(f)
    if 'data_list' not in info:
        raise KeyError(f'{info_path} does not contain `data_list`.')
    return info['data_list']


def apply_axis_align(points_xyz: np.ndarray, axis_align_matrix: Optional[Sequence[Sequence[float]]]) -> np.ndarray:
    if axis_align_matrix is None:
        return points_xyz
    matrix = np.asarray(axis_align_matrix, dtype=np.float32)
    if matrix.shape != (4, 4):
        return points_xyz
    homo = np.concatenate(
        [points_xyz, np.ones((points_xyz.shape[0], 1), dtype=np.float32)],
        axis=1)
    aligned = homo @ matrix.T
    return aligned[:, :3]


def compute_point_roles(
    points_xyz: np.ndarray,
    instances: Sequence[dict],
    layout_verts: Sequence[Sequence[Sequence[float]]],
    horizontal_quads: Sequence[Sequence[Sequence[float]]],
    boundary_ratio: float,
    boundary_min: float,
    layout_dist_thr: float,
    layout_span_pad: float,
) -> Dict[str, np.ndarray]:
    num_points = points_xyz.shape[0]
    inside_any = np.zeros(num_points, dtype=bool)
    boundary_any = np.zeros(num_points, dtype=bool)
    eps = 1e-6

    for instance in instances:
        bbox = np.asarray(instance['bbox_3d'], dtype=np.float32)
        center = bbox[:3]
        size = bbox[3:6]
        half = size / 2.0
        delta = np.abs(points_xyz - center[None, :])
        inside = np.all(delta <= (half[None, :] + eps), axis=1)
        if not np.any(inside):
            continue
        margin = np.maximum(size * boundary_ratio, boundary_min)
        interior_half = np.maximum(half - margin, 0.0)
        interior = np.all(delta <= (interior_half[None, :] + eps), axis=1)
        boundary = inside & (~interior)
        inside_any |= inside
        boundary_any |= boundary

    layout_surface = np.zeros(num_points, dtype=bool)
    for quad in list(layout_verts) + list(horizontal_quads):
        quad_arr = np.asarray(quad, dtype=np.float32).reshape(-1, 3)
        if quad_arr.shape[0] < 4:
            continue
        quad_min = quad_arr.min(axis=0)
        quad_max = quad_arr.max(axis=0)
        quad_size = quad_max - quad_min
        thin_axis = int(np.argmin(quad_size))
        plane_coord = float(quad_arr[:, thin_axis].mean())
        near_plane = np.abs(points_xyz[:, thin_axis] - plane_coord) <= layout_dist_thr
        within_span = np.ones(num_points, dtype=bool)
        for axis in range(3):
            if axis == thin_axis:
                continue
            within_span &= (
                points_xyz[:, axis] >= (quad_min[axis] - layout_span_pad)
            ) & (
                points_xyz[:, axis] <= (quad_max[axis] + layout_span_pad)
            )
        layout_surface |= near_plane & within_span

    object_boundary = boundary_any
    object_interior = inside_any & (~boundary_any)
    background = (~inside_any) & (~layout_surface)
    return dict(
        object_boundary=object_boundary,
        object_interior=object_interior,
        layout_surface=layout_surface & (~inside_any),
        background=background,
    )


def aggregate_voxels(
    points_xyz: np.ndarray,
    point_conf: np.ndarray,
    role_masks: Dict[str, np.ndarray],
    args: argparse.Namespace,
) -> Dict[str, np.ndarray]:
    voxel_coords = np.floor(points_xyz / args.voxel_size).astype(np.int32)
    unique_coords, inverse = np.unique(voxel_coords, axis=0, return_inverse=True)
    num_voxels = unique_coords.shape[0]

    point_conf_sq = point_conf * point_conf

    voxel_count = np.bincount(inverse, minlength=num_voxels).astype(np.float32)
    conf_sum = np.bincount(inverse, weights=point_conf, minlength=num_voxels).astype(np.float32)
    conf_sq_sum = np.bincount(inverse, weights=point_conf_sq, minlength=num_voxels).astype(np.float32)

    voxel_conf_sum = np.clip(conf_sum, args.voxel_conf_min, None)
    if args.voxel_conf_mode == 'mean':
        voxel_conf = voxel_conf_sum / np.clip(voxel_count, 1.0, None)
    else:
        voxel_conf = voxel_conf_sum
    voxel_conf = np.clip(voxel_conf, args.voxel_conf_min, args.voxel_conf_max)

    voxel_conf_mean = conf_sum / np.clip(voxel_count, 1.0, None)
    voxel_conf_var = conf_sq_sum / np.clip(voxel_count, 1.0, None) - voxel_conf_mean * voxel_conf_mean
    voxel_conf_var = np.clip(voxel_conf_var, 0.0, 0.25)

    base_scale = (
        (1.0 - args.voxel_conf_blend) +
        args.voxel_conf_blend * np.power(voxel_conf, args.voxel_conf_power)
    ).astype(np.float32)
    uncertainty_scale = (1.0 - 4.0 * voxel_conf_var).astype(np.float32)
    support_scale = normalize_voxel_density(voxel_count).astype(np.float32)
    voxel_scale = base_scale.copy()
    voxel_scale *= (
        (1.0 - args.voxel_uncertainty_blend) +
        args.voxel_uncertainty_blend * uncertainty_scale
    )
    voxel_scale *= (
        (1.0 - args.voxel_support_reweight_blend) +
        args.voxel_support_reweight_blend * support_scale
    )

    order = np.argsort(inverse, kind='stable')
    inverse_sorted = inverse[order]
    segment_start = np.concatenate((
        np.array([0], dtype=np.int64),
        np.flatnonzero(np.diff(inverse_sorted)) + 1,
    ))

    role_fraction_map = {}
    for role_name, mask in role_masks.items():
        role_fraction_map[role_name] = (
            np.bincount(inverse, weights=mask.astype(np.float32), minlength=num_voxels) /
            np.clip(voxel_count, 1.0, None)
        ).astype(np.float32)

    role_names = np.empty(num_voxels, dtype=object)
    for voxel_index in range(num_voxels):
        if role_fraction_map['object_boundary'][voxel_index] > 0.0:
            role_names[voxel_index] = 'object_boundary'
        elif role_fraction_map['object_interior'][voxel_index] > 0.0:
            role_names[voxel_index] = 'object_interior'
        elif role_fraction_map['layout_surface'][voxel_index] > 0.0:
            role_names[voxel_index] = 'layout_surface'
        else:
            role_names[voxel_index] = 'background'

    return dict(
        voxel_x=unique_coords[:, 0],
        voxel_y=unique_coords[:, 1],
        voxel_z=unique_coords[:, 2],
        point_count=voxel_count,
        conf_mean=voxel_conf_mean.astype(np.float32),
        conf_var=voxel_conf_var.astype(np.float32),
        conf_min=np.zeros(num_voxels, dtype=np.float32),
        conf_max=np.zeros(num_voxels, dtype=np.float32),
        voxel_scale=voxel_scale.astype(np.float32),
        support_scale=support_scale.astype(np.float32),
        uncertainty_scale=uncertainty_scale.astype(np.float32),
        object_ratio=(
            role_fraction_map['object_boundary'] +
            role_fraction_map['object_interior']
        ).astype(np.float32),
        boundary_ratio=role_fraction_map['object_boundary'].astype(np.float32),
        layout_ratio=role_fraction_map['layout_surface'].astype(np.float32),
        role=role_names,
        inverse=inverse,
    )


def fill_conf_range(
    voxel_rows: Dict[str, np.ndarray],
    point_conf: np.ndarray,
) -> None:
    inverse = voxel_rows.pop('inverse')
    num_voxels = voxel_rows['point_count'].shape[0]
    order = np.argsort(inverse, kind='stable')
    inverse_sorted = inverse[order]
    conf_sorted = point_conf[order]
    segment_start = np.concatenate((
        np.array([0], dtype=np.int64),
        np.flatnonzero(np.diff(inverse_sorted)) + 1,
    ))
    conf_min = np.minimum.reduceat(conf_sorted, segment_start).astype(np.float32)
    conf_max = np.maximum.reduceat(conf_sorted, segment_start).astype(np.float32)
    voxel_rows['conf_min'] = conf_min
    voxel_rows['conf_max'] = conf_max


def dataset_specs(project_root: Path, points_subdir: str) -> Dict[str, dict]:
    return {
        'scannet': dict(
            ann_file=project_root / 'data/scannet/scannet_layout_infos_val.pkl',
            points_dir=project_root / f'data/scannet/{points_subdir}',
        ),
        's3dis': dict(
            ann_file=project_root / 'data/s3dis/s3dis_layout_infos_Area_5_unposed.pkl',
            points_dir=project_root / f'data/s3dis/{points_subdir}',
        ),
    }


def update_bucket(summary_store: Dict[str, SummaryBucket], key: str, rows: Dict[str, np.ndarray]) -> None:
    if key not in summary_store:
        summary_store[key] = SummaryBucket()
    summary_store[key].update(rows)


def make_scene_summary(
    dataset_name: str,
    scene_id: str,
    rows: Dict[str, np.ndarray],
) -> Dict[str, object]:
    role_names = rows['role']
    result = dict(
        dataset=dataset_name,
        scene_id=scene_id,
        num_voxels=int(rows['point_count'].shape[0]),
        mean_point_count=float(rows['point_count'].mean()),
        mean_conf_mean=float(rows['conf_mean'].mean()),
        mean_conf_var=float(rows['conf_var'].mean()),
        mean_voxel_scale=float(rows['voxel_scale'].mean()),
    )
    for role_name in DEFAULT_ROLE_NAMES:
        result[f'num_{role_name}'] = int(np.sum(role_names == role_name))
    return result


def write_voxel_rows(
    csv_writer: csv.DictWriter,
    dataset_name: str,
    scene_id: str,
    rows: Dict[str, np.ndarray],
) -> None:
    num_voxels = rows['point_count'].shape[0]
    for index in range(num_voxels):
        csv_writer.writerow(dict(
            dataset=dataset_name,
            scene_id=scene_id,
            voxel_x=int(rows['voxel_x'][index]),
            voxel_y=int(rows['voxel_y'][index]),
            voxel_z=int(rows['voxel_z'][index]),
            point_count=float(rows['point_count'][index]),
            conf_mean=float(rows['conf_mean'][index]),
            conf_var=float(rows['conf_var'][index]),
            conf_min=float(rows['conf_min'][index]),
            conf_max=float(rows['conf_max'][index]),
            voxel_scale=float(rows['voxel_scale'][index]),
            support_scale=float(rows['support_scale'][index]),
            uncertainty_scale=float(rows['uncertainty_scale'][index]),
            object_ratio=float(rows['object_ratio'][index]),
            boundary_ratio=float(rows['boundary_ratio'][index]),
            layout_ratio=float(rows['layout_ratio'][index]),
            role=rows['role'][index],
        ))


def format_metric_line(metric_name: str, metric_dict: Dict[str, Optional[float]]) -> str:
    if metric_dict['count'] == 0 or metric_dict['mean'] is None:
        return f'- `{metric_name}`: empty'
    return (
        f'- `{metric_name}`: mean={metric_dict["mean"]:.4f}, '
        f'std={metric_dict["std"]:.4f}, '
        f'min={metric_dict["min"]:.4f}, '
        f'max={metric_dict["max"]:.4f}, '
        f'n={metric_dict["count"]}'
    )


def derive_observations(summary_json: Dict[str, object]) -> List[str]:
    observations = []
    per_dataset = summary_json['per_dataset']
    for dataset_name, dataset_summary in per_dataset.items():
        roles = dataset_summary['roles']

        def role_mean(role_name: str, metric_name: str) -> Optional[float]:
            role_info = roles.get(role_name)
            if not role_info:
                return None
            return role_info['metrics'][metric_name]['mean']

        layout_count = role_mean('layout_surface', 'point_count')
        boundary_count = role_mean('object_boundary', 'point_count')
        interior_count = role_mean('object_interior', 'point_count')
        boundary_var = role_mean('object_boundary', 'conf_var')
        background_var = role_mean('background', 'conf_var')
        interior_var = role_mean('object_interior', 'conf_var')

        if layout_count is not None and boundary_count is not None and boundary_count > 0:
            observations.append(
                f'- `{dataset_name}` density bias check: layout_surface mean voxel_count='
                f'{layout_count:.3f}, object_boundary={boundary_count:.3f}. '
                '如果前者持续更高，说明 `voxel_count` 更像 layout/density shortcut。')
        if interior_count is not None and boundary_count is not None:
            observations.append(
                f'- `{dataset_name}` boundary sparsity check: object_interior mean voxel_count='
                f'{interior_count:.3f}, object_boundary={boundary_count:.3f}. '
                '如果 boundary 明显更稀，support prior 更容易伤 strict detection。')
        if boundary_var is not None and interior_var is not None:
            observations.append(
                f'- `{dataset_name}` uncertainty conflict check: object_boundary mean conf_var='
                f'{boundary_var:.4f}, object_interior={interior_var:.4f}. '
                '如果 boundary 不低于 interior，shared early penalty 很可能误伤边界。')
        if background_var is not None and boundary_var is not None:
            observations.append(
                f'- `{dataset_name}` noise selectivity check: background mean conf_var='
                f'{background_var:.4f}, object_boundary={boundary_var:.4f}. '
                '如果两者接近，当前 variance proxy 对“噪声 vs 结构复杂性”区分不够纯。')
    return observations


def build_markdown_summary(summary_json: Dict[str, object]) -> str:
    lines = [
        '# GeoVoxel Voxel Diagnostics',
        '',
        f'- total_scenes: {summary_json["total_scenes"]}',
        f'- total_voxels: {summary_json["total_voxels"]}',
        '',
        '## Mechanism Hints',
    ]
    lines.extend(derive_observations(summary_json))
    lines.append('')
    for dataset_name, dataset_summary in summary_json['per_dataset'].items():
        lines.append(f'## Dataset: {dataset_name}')
        lines.append(f'- scenes: {dataset_summary["num_scenes"]}')
        lines.append(f'- voxels: {dataset_summary["all"]["num_voxels"]}')
        lines.append('- overall metrics:')
        for metric_name, metric_dict in dataset_summary['all']['metrics'].items():
            lines.append(f'  {format_metric_line(metric_name, metric_dict)}')
        for role_name, role_summary in dataset_summary['roles'].items():
            lines.append(f'- role `{role_name}`: voxels={role_summary["num_voxels"]}')
            for metric_name in ('point_count', 'conf_mean', 'conf_var', 'voxel_scale'):
                lines.append(f'  {format_metric_line(metric_name, role_summary["metrics"][metric_name])}')
        lines.append('')
    return '\n'.join(lines)


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir
    if not output_dir.is_absolute():
        output_dir = args.project_root / output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    specs = dataset_specs(args.project_root, args.points_subdir)
    voxel_csv_path = output_dir / 'voxel_stats.csv'
    scene_csv_path = output_dir / 'scene_summary.csv'
    summary_json_path = output_dir / 'summary.json'
    summary_md_path = output_dir / 'summary.md'

    voxel_writer = None
    voxel_csv_file = None
    if not args.skip_voxel_csv:
        voxel_csv_file = voxel_csv_path.open('w', newline='')
        voxel_writer = csv.DictWriter(
            voxel_csv_file,
            fieldnames=[
                'dataset', 'scene_id', 'voxel_x', 'voxel_y', 'voxel_z',
                'point_count', 'conf_mean', 'conf_var', 'conf_min', 'conf_max',
                'voxel_scale', 'support_scale', 'uncertainty_scale',
                'object_ratio', 'boundary_ratio', 'layout_ratio', 'role',
            ])
        voxel_writer.writeheader()

    scene_rows: List[Dict[str, object]] = []
    summary_store: Dict[str, SummaryBucket] = {}
    per_dataset_scene_count = defaultdict(int)
    total_voxels = 0
    total_scenes = 0

    try:
        for dataset_name in args.datasets:
            spec = specs[dataset_name]
            info_list = load_info_list(spec['ann_file'])
            if args.max_scenes_per_dataset > 0:
                info_list = info_list[:args.max_scenes_per_dataset]

            for info in info_list:
                scene_id = Path(info['lidar_points']['lidar_path']).stem
                point_path = spec['points_dir'] / info['lidar_points']['lidar_path']
                points = np.fromfile(point_path, dtype=np.float32).reshape(-1, 7)
                points_xyz = points[:, :3]
                if dataset_name == 'scannet':
                    points_xyz = apply_axis_align(points_xyz, info.get('axis_align_matrix'))
                point_conf = normalize_point_confidence(points[:, 3], args)
                point_conf = np.clip(point_conf, args.voxel_conf_min, args.voxel_conf_max)

                role_masks = compute_point_roles(
                    points_xyz=points_xyz,
                    instances=info['instances'],
                    layout_verts=info.get('layout_verts', []),
                    horizontal_quads=info.get('horizontal_quads', []),
                    boundary_ratio=args.boundary_ratio,
                    boundary_min=args.boundary_min,
                    layout_dist_thr=args.layout_dist_thr,
                    layout_span_pad=args.layout_span_pad,
                )
                voxel_rows = aggregate_voxels(
                    points_xyz=points_xyz,
                    point_conf=point_conf,
                    role_masks=role_masks,
                    args=args,
                )
                fill_conf_range(voxel_rows, point_conf)

                scene_rows.append(make_scene_summary(dataset_name, scene_id, voxel_rows))
                if voxel_writer is not None:
                    write_voxel_rows(voxel_writer, dataset_name, scene_id, voxel_rows)

                dataset_all_key = f'{dataset_name}::all'
                update_bucket(summary_store, dataset_all_key, voxel_rows)
                for role_name in DEFAULT_ROLE_NAMES:
                    role_mask = voxel_rows['role'] == role_name
                    role_rows = {
                        key: value[role_mask]
                        for key, value in voxel_rows.items()
                        if isinstance(value, np.ndarray) and value.shape[0] == role_mask.shape[0]
                    }
                    update_bucket(summary_store, f'{dataset_name}::{role_name}', role_rows)

                total_voxels += int(voxel_rows['point_count'].shape[0])
                total_scenes += 1
                per_dataset_scene_count[dataset_name] += 1
    finally:
        if voxel_csv_file is not None:
            voxel_csv_file.close()

    with scene_csv_path.open('w', newline='') as f:
        if scene_rows:
            writer = csv.DictWriter(f, fieldnames=list(scene_rows[0].keys()))
            writer.writeheader()
            writer.writerows(scene_rows)

    per_dataset_summary = {}
    for dataset_name in args.datasets:
        if f'{dataset_name}::all' not in summary_store:
            summary_store[f'{dataset_name}::all'] = SummaryBucket()
        for role_name in DEFAULT_ROLE_NAMES:
            if f'{dataset_name}::{role_name}' not in summary_store:
                summary_store[f'{dataset_name}::{role_name}'] = SummaryBucket()
        dataset_summary = {
            'num_scenes': per_dataset_scene_count[dataset_name],
            'all': summary_store[f'{dataset_name}::all'].to_dict(),
            'roles': {},
        }
        for role_name in DEFAULT_ROLE_NAMES:
            dataset_summary['roles'][role_name] = summary_store[
                f'{dataset_name}::{role_name}'
            ].to_dict()
        per_dataset_summary[dataset_name] = dataset_summary

    summary_json = dict(
        config=dict(
            datasets=args.datasets,
            voxel_size=args.voxel_size,
            points_subdir=args.points_subdir,
            boundary_ratio=args.boundary_ratio,
            boundary_min=args.boundary_min,
            point_conf_norm_mode=args.point_conf_norm_mode,
            point_conf_norm_blend=args.point_conf_norm_blend,
            point_conf_quantile_low=args.point_conf_quantile_low,
            point_conf_quantile_high=args.point_conf_quantile_high,
            voxel_conf_mode=args.voxel_conf_mode,
            voxel_conf_power=args.voxel_conf_power,
            voxel_conf_blend=args.voxel_conf_blend,
            voxel_conf_min=args.voxel_conf_min,
            voxel_conf_max=args.voxel_conf_max,
            voxel_support_reweight_blend=args.voxel_support_reweight_blend,
            voxel_uncertainty_blend=args.voxel_uncertainty_blend,
        ),
        total_scenes=total_scenes,
        total_voxels=total_voxels,
        per_dataset=per_dataset_summary,
        scene_summary_csv=str(scene_csv_path),
        voxel_stats_csv=None if args.skip_voxel_csv else str(voxel_csv_path),
    )

    summary_json_path.write_text(json.dumps(summary_json, indent=2, ensure_ascii=False))
    summary_md_path.write_text(build_markdown_summary(summary_json))

    print(f'Wrote scene summary to: {scene_csv_path}')
    if not args.skip_voxel_csv:
        print(f'Wrote voxel stats to: {voxel_csv_path}')
    print(f'Wrote JSON summary to: {summary_json_path}')
    print(f'Wrote Markdown summary to: {summary_md_path}')


if __name__ == '__main__':
    main()
