import argparse
from pathlib import Path

import torch


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description='Inflate MinkowskiEngine input channels for warm-start.')
    parser.add_argument('input', help='Input checkpoint path.')
    parser.add_argument('output', help='Output checkpoint path.')
    parser.add_argument(
        '--weight-key',
        default='backbone.conv1.kernel',
        help='State-dict key of the first sparse convolution kernel.')
    parser.add_argument(
        '--target-in-channels',
        type=int,
        default=4,
        help='Target number of input channels.')
    parser.add_argument(
        '--extra-init',
        choices=['mean', 'zero', 'repeat_last'],
        default='mean',
        help='How to initialize newly added channels.')
    return parser.parse_args()


def build_extra_channels(
    weight: torch.Tensor,
    num_extra: int,
    mode: str,
) -> torch.Tensor:
    if mode == 'zero':
        shape = list(weight.shape)
        shape[1] = num_extra
        return weight.new_zeros(shape)
    if mode == 'repeat_last':
        return weight[:, -1:, :].repeat(1, num_extra, 1)
    return weight.mean(dim=1, keepdim=True).repeat(1, num_extra, 1)


def main() -> None:
    args = parse_args()
    input_path = Path(args.input)
    output_path = Path(args.output)

    checkpoint = torch.load(input_path, map_location='cpu')
    state_dict = checkpoint.get('state_dict', checkpoint)
    if args.weight_key not in state_dict:
        raise KeyError(
            f'Cannot find `{args.weight_key}` in checkpoint: {input_path}')

    weight = state_dict[args.weight_key]
    if weight.ndim != 3:
        raise ValueError(
            f'Expected 3D sparse kernel tensor, got shape={tuple(weight.shape)}')

    src_in_channels = weight.shape[1]
    dst_in_channels = args.target_in_channels
    if dst_in_channels < src_in_channels:
        raise ValueError(
            f'target_in_channels={dst_in_channels} is smaller than '
            f'source_in_channels={src_in_channels}')

    if dst_in_channels == src_in_channels:
        inflated = weight.clone()
    else:
        extra = build_extra_channels(
            weight, dst_in_channels - src_in_channels, args.extra_init)
        inflated = torch.cat([weight, extra], dim=1)

    state_dict[args.weight_key] = inflated
    checkpoint['state_dict'] = state_dict
    meta = checkpoint.setdefault('meta', {})
    meta['inflated_from'] = str(input_path)
    meta['inflated_weight_key'] = args.weight_key
    meta['inflated_in_channels'] = [src_in_channels, dst_in_channels]
    meta['inflated_extra_init'] = args.extra_init

    output_path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(checkpoint, output_path)

    print(f'Input checkpoint : {input_path}')
    print(f'Output checkpoint: {output_path}')
    print(f'Weight key       : {args.weight_key}')
    print(f'Input channels   : {src_in_channels}')
    print(f'Output channels  : {dst_in_channels}')
    print(f'Extra init       : {args.extra_init}')


if __name__ == '__main__':
    main()
