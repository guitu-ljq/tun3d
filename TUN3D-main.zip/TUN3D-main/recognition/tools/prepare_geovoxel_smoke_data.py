"""
Prepare a small smoke subset for Stage-2 GeoVoxel experiments.

This script:
1. Slices ScanNet/S3DIS annotation pickles into small smoke subsets.
2. Builds explicit GeoConf v2 point clouds only for the referenced samples.
"""

import argparse
import pickle
from pathlib import Path
from typing import Iterable, List

from build_geoconf_bins_v2 import process_file


def dump_subset(src_pkl: Path, dst_pkl: Path, keep: int) -> List[str]:
    with open(src_pkl, "rb") as f:
        data = pickle.load(f)

    subset = dict(data)
    subset["data_list"] = data["data_list"][:keep]

    dst_pkl.parent.mkdir(parents=True, exist_ok=True)
    with open(dst_pkl, "wb") as f:
        pickle.dump(subset, f)

    file_names = [item["lidar_points"]["lidar_path"] for item in subset["data_list"]]
    return file_names


def build_subset_bins(
    file_names: Iterable[str],
    src_dir: Path,
    dst_dir: Path,
    k: int,
    alpha: float,
    fast: bool,
) -> None:
    dst_dir.mkdir(parents=True, exist_ok=True)
    for file_name in file_names:
        src_path = src_dir / file_name
        dst_path = dst_dir / file_name
        if dst_path.exists():
            continue
        process_file(
            src_path=str(src_path),
            dst_path=str(dst_path),
            k=k,
            alpha=alpha,
            fast=fast,
        )


def main() -> None:
    parser = argparse.ArgumentParser(description="Prepare GeoVoxel smoke data.")
    parser.add_argument("--root", type=Path, default=Path("../data"))
    parser.add_argument("--scannet-train", type=int, default=32)
    parser.add_argument("--scannet-val", type=int, default=16)
    parser.add_argument("--s3dis-train", type=int, default=8)
    parser.add_argument("--s3dis-val", type=int, default=16)
    parser.add_argument("--k", type=int, default=16)
    parser.add_argument("--alpha", type=float, default=0.7)
    parser.add_argument("--fast", action="store_true")
    args = parser.parse_args()

    root = args.root

    scannet_files = []
    scannet_files += dump_subset(
        root / "scannet/scannet_layout_infos_train.pkl",
        root / "scannet/scannet_layout_infos_train_smoke.pkl",
        args.scannet_train,
    )
    scannet_files += dump_subset(
        root / "scannet/scannet_layout_infos_val.pkl",
        root / "scannet/scannet_layout_infos_val_smoke.pkl",
        args.scannet_val,
    )
    build_subset_bins(
        scannet_files,
        root / "scannet/points_unposed",
        root / "scannet/points_unposed_geoconf_v2_smoke",
        args.k,
        args.alpha,
        args.fast,
    )

    for area in [1, 2, 3, 4, 6]:
        file_names = dump_subset(
            root / f"s3dis/s3dis_layout_infos_Area_{area}_unposed.pkl",
            root / f"s3dis/s3dis_layout_infos_Area_{area}_unposed_smoke.pkl",
            args.s3dis_train,
        )
        build_subset_bins(
            file_names,
            root / "s3dis/points_unposed",
            root / "s3dis/points_unposed_geoconf_v2_smoke",
            args.k,
            args.alpha,
            args.fast,
        )

    val_files = dump_subset(
        root / "s3dis/s3dis_layout_infos_Area_5_unposed.pkl",
        root / "s3dis/s3dis_layout_infos_Area_5_unposed_smoke.pkl",
        args.s3dis_val,
    )
    build_subset_bins(
        val_files,
        root / "s3dis/points_unposed",
        root / "s3dis/points_unposed_geoconf_v2_smoke",
        args.k,
        args.alpha,
        args.fast,
    )

    print("GeoVoxel smoke data prepared.")
    print(f"scannet_train={args.scannet_train}, scannet_val={args.scannet_val}")
    print(f"s3dis_train_per_area={args.s3dis_train}, s3dis_val={args.s3dis_val}")


if __name__ == "__main__":
    main()
