# Copyright (c) OpenMMLab. All rights reserved.
from typing import Dict, List, Optional, Tuple, Union

import torch
from torch import nn

try:
    import MinkowskiEngine as ME
except ImportError:
    ME = None

from mmdet3d.models.detectors.mink_single_stage import MinkSingleStage3DDetector
from mmdet3d.registry import MODELS
from mmengine.optim import OptimWrapper


@MODELS.register_module()
class GeoConfVoxelMinkSingleStage3DDetector(MinkSingleStage3DDetector):
    """Stage-2 detector with confidence-aware voxel aggregation.

    Expected point format:
        [x, y, z, conf, r, g, b]

    The detector converts point-wise confidence into voxel-wise reliability and
    uses it to suppress unreliable voxels before the sparse backbone. The
    reliability can also be kept as an explicit voxel feature or concatenated
    with a raw RGB residual path for layout-friendly v2.1 experiments.
    """

    def __init__(
        self,
        voxel_conf_power: float = 1.0,
        voxel_conf_min: float = 0.05,
        voxel_conf_max: float = 1.0,
        voxel_conf_mode: str = 'sum',
        voxel_conf_blend: float = 1.0,
        voxel_density_blend: float = 1.0,
        voxel_support_reweight_blend: float = 0.0,
        voxel_uncertainty_blend: float = 0.0,
        voxel_unified_gate_blend: float = 1.0,
        voxel_feature_mode: str = 'scaled_rgb',
        voxel_detail_blend: float = 0.0,
        point_conf_norm_mode: str = 'none',
        point_conf_norm_blend: float = 1.0,
        point_conf_quantile_low: float = 0.05,
        point_conf_quantile_high: float = 0.95,
        point_conf_eps: float = 1e-6,
        conflict_optim_mode: str = 'none',
        cagrad_alpha: float = 0.5,
        cagrad_rescale: int = 1,
        cagrad_shared_param_mode: str = 'backbone_neck',
        cagrad_grid_points: int = 101,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        if ME is None:
            raise ImportError(
                'Please follow `get_started.md` to install MinkowskiEngine.`')
        if voxel_conf_mode not in {'sum', 'mean'}:
            raise ValueError(
                f'Unsupported voxel_conf_mode={voxel_conf_mode}, '
                "expected 'sum' or 'mean'.")
        if not 0.0 <= voxel_density_blend <= 1.0:
            raise ValueError(
                'voxel_density_blend must satisfy 0 <= blend <= 1.')
        if not 0.0 <= voxel_support_reweight_blend <= 1.0:
            raise ValueError(
                'voxel_support_reweight_blend must satisfy 0 <= blend <= 1.')
        if not 0.0 <= voxel_uncertainty_blend <= 1.0:
            raise ValueError(
                'voxel_uncertainty_blend must satisfy 0 <= blend <= 1.')
        if not 0.0 <= voxel_unified_gate_blend <= 1.0:
            raise ValueError(
                'voxel_unified_gate_blend must satisfy 0 <= blend <= 1.')
        if not 0.0 <= voxel_detail_blend <= 1.0:
            raise ValueError(
                'voxel_detail_blend must satisfy 0 <= blend <= 1.')
        if voxel_feature_mode not in {
                'scaled_rgb',
                'scaled_rgb_conf',
                'rgb_conf',
                'scaled_rgb_raw_conf',
                'scaled_rgb_detail_conf',
                'scaled_rgb_raw_conf_unified_gate',
                'scaled_rgb_raw_conf_count'}:
            raise ValueError(
                f'Unsupported voxel_feature_mode={voxel_feature_mode}, '
                "expected 'scaled_rgb', 'scaled_rgb_conf', 'rgb_conf', "
                "'scaled_rgb_raw_conf', 'scaled_rgb_detail_conf', "
                "'scaled_rgb_raw_conf_unified_gate', or "
                "'scaled_rgb_raw_conf_count'.")
        if point_conf_norm_mode not in {'none', 'scene_minmax', 'scene_percentile'}:
            raise ValueError(
                f'Unsupported point_conf_norm_mode={point_conf_norm_mode}, '
                "expected 'none', 'scene_minmax', or 'scene_percentile'.")
        if not 0.0 <= point_conf_norm_blend <= 1.0:
            raise ValueError(
                'point_conf_norm_blend must satisfy 0 <= blend <= 1.')
        if not 0.0 <= point_conf_quantile_low < point_conf_quantile_high <= 1.0:
            raise ValueError(
                'point_conf_quantile_low/high must satisfy '
                '0 <= low < high <= 1.')
        if conflict_optim_mode not in {'none', 'cagrad'}:
            raise ValueError(
                f'Unsupported conflict_optim_mode={conflict_optim_mode}, '
                "expected 'none' or 'cagrad'.")
        if cagrad_alpha < 0.0:
            raise ValueError('cagrad_alpha must satisfy alpha >= 0.')
        if cagrad_rescale not in {0, 1, 2}:
            raise ValueError('cagrad_rescale must be 0, 1, or 2.')
        if cagrad_shared_param_mode not in {'backbone_neck', 'backbone_only'}:
            raise ValueError(
                'cagrad_shared_param_mode must be "backbone_neck" or '
                '"backbone_only".')
        if cagrad_grid_points < 3:
            raise ValueError('cagrad_grid_points must be >= 3.')
        self.voxel_conf_power = voxel_conf_power
        self.voxel_conf_min = voxel_conf_min
        self.voxel_conf_max = voxel_conf_max
        self.voxel_conf_mode = voxel_conf_mode
        self.voxel_conf_blend = voxel_conf_blend
        self.voxel_density_blend = voxel_density_blend
        self.voxel_support_reweight_blend = voxel_support_reweight_blend
        self.voxel_uncertainty_blend = voxel_uncertainty_blend
        self.voxel_unified_gate_blend = voxel_unified_gate_blend
        self.voxel_feature_mode = voxel_feature_mode
        self.voxel_detail_blend = voxel_detail_blend
        self.point_conf_norm_mode = point_conf_norm_mode
        self.point_conf_norm_blend = point_conf_norm_blend
        self.point_conf_quantile_low = point_conf_quantile_low
        self.point_conf_quantile_high = point_conf_quantile_high
        self.point_conf_eps = point_conf_eps
        self.conflict_optim_mode = conflict_optim_mode
        self.cagrad_alpha = cagrad_alpha
        self.cagrad_rescale = cagrad_rescale
        self.cagrad_shared_param_mode = cagrad_shared_param_mode
        self.cagrad_grid_points = cagrad_grid_points
        self.voxel_unified_bottleneck = None
        if self.voxel_feature_mode == 'scaled_rgb_raw_conf_unified_gate':
            # Keep the channel count identical to the v2.1/v2.3 dual-path setup
            # so the sparse backbone interface stays unchanged.
            self.voxel_unified_bottleneck = nn.Linear(7, 7)
            self._init_voxel_unified_bottleneck()

    def _init_voxel_unified_bottleneck(self) -> None:
        assert self.voxel_unified_bottleneck is not None
        with torch.no_grad():
            self.voxel_unified_bottleneck.weight.zero_()
            self.voxel_unified_bottleneck.bias.zero_()
            # Start from identity so v2.9a behaves like a gentle gated variant
            # of the dual-path baseline instead of a hard feature rewrite.
            self.voxel_unified_bottleneck.weight.fill_diagonal_(1.0)

    def _normalize_voxel_density(self, voxel_count: torch.Tensor) -> torch.Tensor:
        count_scale = torch.log1p(voxel_count)
        return count_scale / torch.log1p(voxel_count.max().clamp(min=1.0))

    def _normalize_point_confidence(
        self,
        confidence: torch.Tensor,
    ) -> torch.Tensor:
        if self.point_conf_norm_mode == 'none':
            return confidence

        flat_conf = confidence[:, 0]
        if self.point_conf_norm_mode == 'scene_minmax':
            lower = flat_conf.min()
            upper = flat_conf.max()
        else:
            lower = torch.quantile(flat_conf, self.point_conf_quantile_low)
            upper = torch.quantile(flat_conf, self.point_conf_quantile_high)

        scale = (upper - lower).clamp(min=self.point_conf_eps)
        normalized = (confidence - lower) / scale
        normalized = normalized.clamp(min=0.0, max=1.0)
        return (
            (1.0 - self.point_conf_norm_blend) * confidence +
            self.point_conf_norm_blend * normalized)

    def _compose_voxel_features(
        self,
        voxel_rgb: torch.Tensor,
        voxel_conf: torch.Tensor,
        voxel_scale: torch.Tensor,
        voxel_count: torch.Tensor,
    ) -> torch.Tensor:
        scaled_rgb = voxel_rgb * voxel_scale
        if self.voxel_feature_mode == 'scaled_rgb':
            return scaled_rgb
        if self.voxel_feature_mode == 'scaled_rgb_conf':
            return torch.cat([scaled_rgb, voxel_conf], dim=1)
        if self.voxel_feature_mode == 'scaled_rgb_detail_conf':
            # Preserve a dedicated detail path, but keep it confidence-aware:
            # mid-confidence transition voxels retain more high-frequency cues,
            # while very low-confidence noise no longer leaks through as raw RGB.
            detail_focus = 4.0 * voxel_conf * (1.0 - voxel_conf)
            detail_scale = (
                (1.0 - self.voxel_detail_blend) +
                self.voxel_detail_blend * detail_focus)
            detail_rgb = voxel_rgb * detail_scale
            return torch.cat([scaled_rgb, detail_rgb, voxel_conf], dim=1)
        if self.voxel_feature_mode == 'scaled_rgb_raw_conf':
            # Preserve an unsuppressed structural path so layout cues are not
            # fully erased by confidence-aware gating before the backbone.
            return torch.cat([scaled_rgb, voxel_rgb, voxel_conf], dim=1)
        if self.voxel_feature_mode == 'scaled_rgb_raw_conf_unified_gate':
            return torch.cat([scaled_rgb, voxel_rgb, voxel_conf], dim=1)
        if self.voxel_feature_mode == 'scaled_rgb_raw_conf_count':
            # Explicit voxel density helps distinguish dense, reliable support
            # from isolated noisy voxels, which is especially useful in clutter.
            count_scale = self._normalize_voxel_density(voxel_count)
            count_scale = count_scale * self.voxel_density_blend
            return torch.cat([scaled_rgb, voxel_rgb, voxel_conf, count_scale], dim=1)
        return torch.cat([voxel_rgb, voxel_conf], dim=1)

    def _apply_unified_bottleneck(
        self,
        voxel_features: torch.Tensor,
        voxel_scale: torch.Tensor,
    ) -> torch.Tensor:
        if self.voxel_feature_mode != 'scaled_rgb_raw_conf_unified_gate':
            return voxel_features
        assert self.voxel_unified_bottleneck is not None
        mixed_features = self.voxel_unified_bottleneck(voxel_features)
        gate = (
            (1.0 - self.voxel_unified_gate_blend) +
            self.voxel_unified_gate_blend * voxel_scale)
        # Gate the fused feature right before the sparse backbone so neither
        # raw RGB nor explicit confidence can bypass the reliability signal.
        # The residual blend keeps early training closer to the v2.3 regime.
        return mixed_features * gate

    def _build_voxel_tensor(self, points: List[torch.Tensor]) -> "ME.SparseTensor":
        collate_inputs = []
        for point_tensor in points:
            if point_tensor.size(1) < 7:
                raise ValueError(
                    'GeoConfVoxelMinkSingleStage3DDetector expects point tensors '
                    'with shape (N, 7): [x, y, z, conf, r, g, b].'
                )

            confidence = self._normalize_point_confidence(point_tensor[:, 3:4]).clamp(
                min=self.voxel_conf_min, max=self.voxel_conf_max)
            rgb = point_tensor[:, 4:7]
            counts = torch.ones_like(confidence)

            # Aggregate weighted RGB, confidence moments, and voxel occupancy.
            weighted_features = torch.cat(
                [rgb * confidence, confidence, confidence.square(), counts], dim=1)
            collate_inputs.append(
                (point_tensor[:, :3] / self.voxel_size, weighted_features))

        coordinates, features = ME.utils.batch_sparse_collate(
            collate_inputs, device=points[0].device)
        sparse_inputs = ME.SparseTensor(coordinates=coordinates, features=features)

        voxel_conf_sum = sparse_inputs.features[:, 3:4].clamp(
            min=self.voxel_conf_min)
        voxel_conf_sq_sum = sparse_inputs.features[:, 4:5]
        voxel_count = sparse_inputs.features[:, 5:6].clamp(min=1.0)
        if self.voxel_conf_mode == 'mean':
            voxel_conf = voxel_conf_sum / voxel_count
        else:
            voxel_conf = voxel_conf_sum
        voxel_conf = voxel_conf.clamp(
            min=self.voxel_conf_min, max=self.voxel_conf_max)
        voxel_rgb = sparse_inputs.features[:, :3] / voxel_conf_sum
        voxel_scale = (
            (1.0 - self.voxel_conf_blend) +
            self.voxel_conf_blend * voxel_conf.pow(self.voxel_conf_power))
        if self.voxel_uncertainty_blend > 0.0:
            # Penalize voxels whose point-level confidence is internally
            # inconsistent, which often indicates propagated reconstruction noise.
            voxel_conf_mean = voxel_conf_sum / voxel_count
            voxel_conf_var = (
                voxel_conf_sq_sum / voxel_count - voxel_conf_mean.square())
            voxel_conf_var = voxel_conf_var.clamp(min=0.0, max=0.25)
            voxel_uncertainty_scale = 1.0 - 4.0 * voxel_conf_var
            voxel_scale = voxel_scale * (
                (1.0 - self.voxel_uncertainty_blend) +
                self.voxel_uncertainty_blend * voxel_uncertainty_scale)
        if self.voxel_support_reweight_blend > 0.0:
            # Use occupancy as an auxiliary reliability prior without exposing
            # density as a new backbone channel.
            support_scale = self._normalize_voxel_density(voxel_count)
            voxel_scale = voxel_scale * (
                (1.0 - self.voxel_support_reweight_blend) +
                self.voxel_support_reweight_blend * support_scale)
        voxel_features = self._compose_voxel_features(
            voxel_rgb=voxel_rgb,
            voxel_conf=voxel_conf,
            voxel_scale=voxel_scale,
            voxel_count=voxel_count)
        voxel_features = self._apply_unified_bottleneck(
            voxel_features=voxel_features, voxel_scale=voxel_scale)

        return ME.SparseTensor(
            features=voxel_features,
            coordinate_map_key=sparse_inputs.coordinate_map_key,
            coordinate_manager=sparse_inputs.coordinate_manager,
        )

    def extract_feat(
        self, batch_inputs_dict: Dict[str, torch.Tensor]
    ) -> Union[List["ME.SparseTensor"], Dict[str, torch.Tensor]]:
        points = batch_inputs_dict['points']
        x = self._build_voxel_tensor(points)

        x = self.backbone(x)
        if self.with_neck:
            x = self.neck(x)
        return x

    def _collect_trainable_params(
        self,
        module: Optional[nn.Module],
    ) -> List[nn.Parameter]:
        if module is None:
            return []
        return [param for param in module.parameters() if param.requires_grad]

    def _get_cagrad_shared_params(self) -> List[nn.Parameter]:
        shared_params = self._collect_trainable_params(self.backbone)
        if self.cagrad_shared_param_mode == 'backbone_neck':
            shared_params.extend(self._collect_trainable_params(self.neck))
        return shared_params

    def _flatten_shared_grads(
        self,
        grads: Tuple[Optional[torch.Tensor], ...],
        shared_params: List[nn.Parameter],
    ) -> torch.Tensor:
        flat_grads = []
        for grad, param in zip(grads, shared_params):
            if grad is None:
                flat_grads.append(torch.zeros_like(param).reshape(-1))
            else:
                flat_grads.append(grad.reshape(-1))
        return torch.cat(flat_grads, dim=0)

    def _set_shared_gradients(
        self,
        shared_params: List[nn.Parameter],
        flat_grad: torch.Tensor,
    ) -> None:
        offset = 0
        for param in shared_params:
            numel = param.numel()
            grad_slice = flat_grad[offset:offset + numel].view_as(param)
            if param.grad is None:
                param.grad = grad_slice.clone()
            else:
                param.grad.copy_(grad_slice)
            offset += numel

    def _cagrad_weights_two_tasks(
        self,
        grad_matrix: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        device = grad_matrix.device
        dtype = grad_matrix.dtype
        gram = grad_matrix.t().mm(grad_matrix)
        uniform = torch.full((2,), 0.5, device=device, dtype=dtype)
        g0 = grad_matrix.mean(dim=1)
        g0_norm = (gram.mean() + 1e-8).sqrt()
        penalty = self.cagrad_alpha * g0_norm
        if penalty.item() == 0:
            return uniform, g0

        candidates = torch.linspace(
            0.0, 1.0, steps=self.cagrad_grid_points, device=device, dtype=dtype)
        weights = torch.stack([candidates, 1.0 - candidates], dim=1)
        gw = weights.mm(gram)
        obj = gw.mm(uniform.view(-1, 1)).squeeze(1) + penalty * (
            (weights.mm(gram) * weights).sum(dim=1).clamp(min=1e-8).sqrt())
        best_idx = torch.argmin(obj)
        best_weight = weights[best_idx]
        gw_vec = grad_matrix.mm(best_weight.view(-1, 1)).squeeze(1)
        gw_norm = gw_vec.norm()
        if gw_norm.item() == 0:
            return best_weight, g0

        lambd = penalty / (gw_norm + 1e-8)
        merged_grad = g0 + lambd * gw_vec
        if self.cagrad_rescale == 1:
            merged_grad = merged_grad / (1.0 + self.cagrad_alpha ** 2)
        elif self.cagrad_rescale == 2:
            merged_grad = merged_grad / (1.0 + self.cagrad_alpha)
        return best_weight, merged_grad

    def _compute_cagrad_gradient(
        self,
        shared_params: List[nn.Parameter],
        task_losses: Dict[str, torch.Tensor],
    ) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        task_names = list(task_losses.keys())
        if len(task_names) != 2:
            raise ValueError(
                f'CAGrad currently expects exactly 2 tasks, got {task_names}.')

        task_grads = []
        for task_idx, task_name in enumerate(task_names):
            grads = torch.autograd.grad(
                task_losses[task_name],
                shared_params,
                retain_graph=True,
                allow_unused=True)
            task_grads.append(self._flatten_shared_grads(grads, shared_params))
        grad_matrix = torch.stack(task_grads, dim=1)
        weights, merged_grad = self._cagrad_weights_two_tasks(grad_matrix)

        det_grad = grad_matrix[:, 0]
        layout_grad = grad_matrix[:, 1]
        det_norm = det_grad.norm()
        layout_norm = layout_grad.norm()
        cosine = torch.zeros(1, device=merged_grad.device, dtype=merged_grad.dtype)
        if det_norm.item() > 0 and layout_norm.item() > 0:
            cosine = torch.dot(det_grad, layout_grad) / (
                det_norm * layout_norm + 1e-8)

        stats = dict(
            cagrad_det_weight=weights[0].detach(),
            cagrad_layout_weight=weights[1].detach(),
            cagrad_shared_cos=cosine.detach(),
            cagrad_shared_grad_norm=merged_grad.norm().detach(),
        )
        return merged_grad, stats

    def _build_cagrad_task_losses(
        self,
        losses: Dict[str, torch.Tensor],
    ) -> Dict[str, torch.Tensor]:
        layout_task = losses['layout_loss'] + losses['cls_layout_loss']
        if 'layout_boundary_loss' in losses:
            layout_task = layout_task + losses['layout_boundary_loss']
        task_losses = {
            'det': losses['bbox_loss'] + losses['cls_bbox_loss'],
            'layout': layout_task,
        }
        return task_losses

    def train_step(self, data: Union[dict, tuple, list],
                   optim_wrapper: OptimWrapper) -> Dict[str, torch.Tensor]:
        if self.conflict_optim_mode != 'cagrad':
            return super().train_step(data, optim_wrapper)

        with optim_wrapper.optim_context(self):
            data = self.data_preprocessor(data, True)
            losses = self._run_forward(data, mode='loss')  # type: ignore

        parsed_losses, log_vars = self.parse_losses(losses)  # type: ignore
        shared_params = self._get_cagrad_shared_params()
        if not shared_params:
            optim_wrapper.update_params(parsed_losses)
            return log_vars

        task_losses = self._build_cagrad_task_losses(losses)
        scaled_total_loss = optim_wrapper.scale_loss(parsed_losses)
        scaled_task_losses = {
            name: optim_wrapper.scale_loss(loss)
            for name, loss in task_losses.items()
        }

        optim_wrapper.zero_grad()
        merged_grad, cagrad_stats = self._compute_cagrad_gradient(
            shared_params=shared_params,
            task_losses=scaled_task_losses)
        scaled_total_loss.backward()
        self._set_shared_gradients(shared_params, merged_grad)
        optim_wrapper._inner_count += 1
        if optim_wrapper.should_update():
            optim_wrapper.step()
            optim_wrapper.zero_grad()

        log_vars.update(cagrad_stats)
        log_vars['det_task_loss'] = task_losses['det'].detach()
        log_vars['layout_task_loss'] = task_losses['layout'].detach()
        return log_vars
