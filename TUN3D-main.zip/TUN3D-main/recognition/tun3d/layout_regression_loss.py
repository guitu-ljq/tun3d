from typing import Optional

import torch
from torch import Tensor
import torch.nn as nn
from mmdet3d.registry import MODELS
from mmdet.models.losses.utils import weighted_loss


@weighted_loss
def l1_loss_bev(pred_layout, gt_layout):
    """Compute L1 loss for layout quads.

    Args:
        pred_layout (Tensor): Predicted layout, shape (..., 5).
        gt_layout (Tensor): Ground-truth layout, same shape as pred_layout.

    Returns:
        Tensor: Element-wise L1 loss.
    """

    coord_error = torch.sum(
        torch.abs(pred_layout[..., :4] - gt_layout[..., :4]), dim=-1)
    height_error = torch.abs(pred_layout[..., 4] - gt_layout[..., 4])
    return coord_error + height_error


@MODELS.register_module()
class L1Loss(nn.Module):
    """Normalized L1 loss wrapper for layout regression.

    Args:
        reduction (str): Reduction method ('mean', 'sum', 'none'). Default: 'mean'.
        normalization (bool): Whether to normalize the loss. Default: False.
        loss_weight (float): Scaling factor for the loss. Default: 1.0.

    """

    def __init__(self,
                 reduction: str = 'mean',
                 normalization: bool = False,
                 loss_weight: float = 1.0):
        super(L1Loss, self).__init__()
        self.loss_weight = loss_weight
        self.reduction = reduction
        self.normalization = normalization
        self.loss = l1_loss_bev

    def forward(self,
                pred: Tensor,
                target: Tensor,
                weight: Optional[Tensor] = None,
                reduction_override: Optional[str] = None,
                **kwargs):

        if weight is not None and not torch.any(weight > 0):
            return pred.sum() * weight.sum()  # 0
        assert reduction_override in (None, 'none', 'mean', 'sum')
        reduction = (
            reduction_override if reduction_override else self.reduction)
        if weight is not None and weight.dim() > 1:
            weight = weight.mean(-1)
        loss = self.loss_weight * self.loss(
            pred,
            target,
            weight,
            reduction=reduction,
            **kwargs)

        return loss


@weighted_loss
def layout_boundary_loss(pred_layout,
                         gt_layout,
                         center_weight: float = 0.5,
                         length_weight: float = 0.75,
                         direction_weight: float = 1.0,
                         height_weight: float = 0.25,
                         eps: float = 1e-6):
    """Boundary-aware structural loss for layout centerlines.

    The 5D layout parameterization stores two BEV points and one height.
    Compared with plain point-wise L1, this loss explicitly constrains the
    centerline center, span length, and orientation so layout supervision
    better protects structural boundaries.
    """
    pred_center = 0.5 * (pred_layout[..., :2] + pred_layout[..., 2:4])
    gt_center = 0.5 * (gt_layout[..., :2] + gt_layout[..., 2:4])
    center_error = torch.sum(torch.abs(pred_center - gt_center), dim=-1)

    pred_vec = pred_layout[..., 2:4] - pred_layout[..., :2]
    gt_vec = gt_layout[..., 2:4] - gt_layout[..., :2]
    pred_len = torch.norm(pred_vec, dim=-1)
    gt_len = torch.norm(gt_vec, dim=-1)
    length_error = torch.abs(pred_len - gt_len)

    pred_dir = pred_vec / pred_len.unsqueeze(-1).clamp(min=eps)
    gt_dir = gt_vec / gt_len.unsqueeze(-1).clamp(min=eps)
    direction_error = 1.0 - torch.sum(pred_dir * gt_dir, dim=-1).clamp(
        min=-1.0, max=1.0)

    height_error = torch.abs(pred_layout[..., 4] - gt_layout[..., 4])
    return (
        center_weight * center_error +
        length_weight * length_error +
        direction_weight * direction_error +
        height_weight * height_error)


@MODELS.register_module()
class LayoutBoundaryLoss(nn.Module):
    """Boundary-aware auxiliary loss for layout regression."""

    def __init__(self,
                 reduction: str = 'mean',
                 loss_weight: float = 1.0,
                 center_weight: float = 0.5,
                 length_weight: float = 0.75,
                 direction_weight: float = 1.0,
                 height_weight: float = 0.25):
        super().__init__()
        self.reduction = reduction
        self.loss_weight = loss_weight
        self.center_weight = center_weight
        self.length_weight = length_weight
        self.direction_weight = direction_weight
        self.height_weight = height_weight

    def forward(self,
                pred: Tensor,
                target: Tensor,
                weight: Optional[Tensor] = None,
                reduction_override: Optional[str] = None,
                **kwargs):
        if weight is not None and not torch.any(weight > 0):
            return pred.sum() * weight.sum()
        assert reduction_override in (None, 'none', 'mean', 'sum')
        reduction = reduction_override if reduction_override else self.reduction
        if weight is not None and weight.dim() > 1:
            weight = weight.mean(-1)
        return self.loss_weight * layout_boundary_loss(
            pred,
            target,
            weight,
            reduction=reduction,
            center_weight=self.center_weight,
            length_weight=self.length_weight,
            direction_weight=self.direction_weight,
            height_weight=self.height_weight,
            **kwargs)
