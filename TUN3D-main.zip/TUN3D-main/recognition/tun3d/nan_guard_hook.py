from typing import Any

import torch
from mmengine.hooks import Hook
from mmengine.logging import print_log
from mmengine.registry import HOOKS


def _find_nonfinite(obj: Any, prefix: str = ''):
    hits = []
    if torch.is_tensor(obj):
        if obj.dtype.is_floating_point:
            bad = (~torch.isfinite(obj)).sum().item()
            if bad:
                hits.append((prefix or '<tensor>', int(bad), tuple(obj.shape)))
        return hits
    if isinstance(obj, dict):
        for key, value in obj.items():
            child = f'{prefix}.{key}' if prefix else str(key)
            hits.extend(_find_nonfinite(value, child))
        return hits
    if isinstance(obj, (list, tuple)):
        for idx, value in enumerate(obj):
            child = f'{prefix}[{idx}]' if prefix else f'[{idx}]'
            hits.extend(_find_nonfinite(value, child))
    return hits


def _summarize_data_batch(data_batch: Any) -> str:
    if data_batch is None:
        return 'data_batch=None'
    try:
        if isinstance(data_batch, dict):
            parts = [f'keys={list(data_batch.keys())}']
            data_samples = data_batch.get('data_samples')
            if isinstance(data_samples, (list, tuple)) and data_samples:
                sample = data_samples[0]
                meta = getattr(sample, 'metainfo', {}) or {}
                short_meta = {}
                for key in ('lidar_path', 'lidar_idx', 'sample_idx', 'scan_id', 'scene_id', 'img_path'):
                    if key in meta:
                        short_meta[key] = meta[key]
                if short_meta:
                    parts.append(f'first_sample_meta={short_meta}')
            return '; '.join(parts)
        return f'data_batch_type={type(data_batch).__name__}'
    except Exception as exc:  # pragma: no cover - debug fallback
        return f'failed_to_summarize_data_batch: {exc}'


@HOOKS.register_module()
class NaNGuardHook(Hook):
    """Fail fast when non-finite values first appear during train/val."""

    priority = 'VERY_HIGH'

    def __init__(self, check_params=True, check_grads=True):
        self.check_params = check_params
        self.check_grads = check_grads

    def _check_model(self, runner):
        model = runner.model
        bad = []
        for name, param in model.named_parameters():
            if self.check_params and param.dtype.is_floating_point:
                count = (~torch.isfinite(param)).sum().item()
                if count:
                    bad.append((f'param:{name}', int(count), tuple(param.shape)))
            if self.check_grads and param.grad is not None and param.grad.dtype.is_floating_point:
                count = (~torch.isfinite(param.grad)).sum().item()
                if count:
                    bad.append((f'grad:{name}', int(count), tuple(param.grad.shape)))
            if len(bad) >= 20:
                break
        return bad

    def _raise_with_context(self, runner, stage, batch_idx, data_batch, bad_outputs, bad_model):
        summary = _summarize_data_batch(data_batch)
        lines = [
            f'NaNGuardHook detected non-finite values during {stage} at iter={runner.iter}, batch_idx={batch_idx}.',
            summary,
        ]
        if bad_outputs:
            lines.append(f'non-finite outputs: {bad_outputs[:20]}')
        if bad_model:
            lines.append(f'non-finite model states: {bad_model[:20]}')
        message = '\n'.join(lines)
        print_log(message, logger='current')
        raise RuntimeError(message)

    def after_train_iter(self, runner, batch_idx, data_batch=None, outputs=None):
        bad_outputs = _find_nonfinite(outputs, prefix='outputs')
        bad_model = self._check_model(runner)
        if bad_outputs or bad_model:
            self._raise_with_context(
                runner,
                stage='after_train_iter',
                batch_idx=batch_idx,
                data_batch=data_batch,
                bad_outputs=bad_outputs,
                bad_model=bad_model)

    def before_val_epoch(self, runner):
        bad_model = self._check_model(runner)
        if bad_model:
            self._raise_with_context(
                runner,
                stage='before_val_epoch',
                batch_idx=-1,
                data_batch=None,
                bad_outputs=[],
                bad_model=bad_model)
