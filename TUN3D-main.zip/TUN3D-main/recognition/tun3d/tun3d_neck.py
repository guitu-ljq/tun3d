# Copyright (c) OpenMMLab. All rights reserved.
# Adapted from https://github.com/SamsungLabs/tr3d/blob/master/mmdet3d/models/necks/tr3d_neck.py # noqa
from typing import List, Tuple

try:
    import MinkowskiEngine as ME
    from MinkowskiEngine import SparseTensor
except ImportError:
    # Please follow getting_started.md to install MinkowskiEngine.
    ME = SparseTensor = None
    pass

from mmengine.model import BaseModule
from torch import nn

from mmdet3d.registry import MODELS


@MODELS.register_module()
class TUN3DNeck(BaseModule):
    r"""Neck of TUN3D. Same as in `TR3D <https://arxiv.org/abs/2302.02858>`_.

    Args:
        in_channels (tuple[int]): Number of channels in input tensors.
        out_channels (int): Number of channels in output tensors.
    """

    def __init__(self, in_channels: Tuple[int], out_channels: int):
        super(TUN3DNeck, self).__init__()
        self._init_layers(in_channels[1:], out_channels)

    def _init_layers(self, in_channels: Tuple[int], out_channels: int):
        """Initialize layers.

        Args:
            in_channels (tuple[int]): Number of channels in input tensors.
            out_channels (int): Number of channels in output tensors.
        """
        for i in range(len(in_channels)):
            if i > 0:
                self.add_module(
                    f'up_block_{i}',
                    self._make_block(in_channels[i], in_channels[i - 1], generative=True,
                                     stride=2))
            if i < len(in_channels) - 1:
                self.add_module(
                    f'lateral_block_{i}',
                    self._make_block(in_channels[i], in_channels[i]))
                self.add_module(f'out_block_{i}',
                                self._make_block(in_channels[i], out_channels))

    def init_weights(self):
        """Initialize weights."""
        for m in self.modules():
            if isinstance(m, ME.MinkowskiConvolution):
                ME.utils.kaiming_normal_(
                    m.kernel, mode='fan_out', nonlinearity='relu')

            if isinstance(m, ME.MinkowskiBatchNorm):
                nn.init.constant_(m.bn.weight, 1)
                nn.init.constant_(m.bn.bias, 0)

    def forward(self, x: List[SparseTensor]) -> List[SparseTensor]:
        """Forward pass.

        Args:
            x (list[SparseTensor]): Features from the backbone.

        Returns:
            List[Tensor]: Output features from the neck.
        """
        x = x[1:]
        outs = []
        inputs = x
        x = inputs[-1]
        for i in range(len(inputs) - 1, -1, -1):
            if i < len(inputs) - 1:
                x = self.__getattr__(f'up_block_{i + 1}')(x)
                x = inputs[i] + x
                x = self.__getattr__(f'lateral_block_{i}')(x)
                out = self.__getattr__(f'out_block_{i}')(x)
                outs.append(out)
        return outs[::-1]

    @staticmethod
    def _make_block(in_channels: int,
                    out_channels: int,
                    dimension: int = 3,
                    generative: bool = False,
                    stride: int = 1) -> nn.Module:
        """Construct Conv-Norm-Act block.

        Args:
            in_channels (int): Number of input channels.
            out_channels (int): Number of output channels.
            generative (bool): Use generative convolution if True.
                Defaults to False.
            stride (int): Stride of the convolution. Defaults to 1.

        Returns:
            torch.nn.Module: With corresponding layers.
        """
        conv = ME.MinkowskiGenerativeConvolutionTranspose if generative \
            else ME.MinkowskiConvolution
        return nn.Sequential(
            conv(
                in_channels,
                out_channels,
                kernel_size=3,
                stride=stride,
                dimension=dimension), 
            ME.MinkowskiBatchNorm(out_channels),
            ME.MinkowskiReLU(inplace=True))


@MODELS.register_module()
class TUN3DLateSplitNeck(TUN3DNeck):
    r"""Late-split neck for conflict-aware selective sharing.

    This neck keeps the original shared top-down fusion unchanged and only
    refines selected late output levels with branch-specific sparse blocks.
    It is the smallest structural step from a fully shared neck towards a
    partially shared neck for layout and detection.

    Args:
        in_channels (tuple[int]): Number of channels in input tensors.
        out_channels (int): Number of channels in output tensors.
        split_levels (tuple[int]): Output levels to refine separately.
        layout_split_blend (float): Residual blend for layout-specific refine.
        det_split_blend (float): Residual blend for detection-specific refine.
        split_kernel_size (int): Kernel size of branch-specific refine blocks.
    """

    def __init__(self,
                 in_channels: Tuple[int],
                 out_channels: int,
                 split_levels: Tuple[int, ...] = (1,),
                 layout_split_blend: float = 1.0,
                 det_split_blend: float = 0.0,
                 split_kernel_size: int = 3):
        num_out_levels = max(len(in_channels) - 2, 0)
        if split_kernel_size <= 0 or split_kernel_size % 2 == 0:
            raise ValueError(
                'split_kernel_size must be a positive odd integer.')
        for blend_name, blend_value in (
                ('layout_split_blend', layout_split_blend),
                ('det_split_blend', det_split_blend)):
            if not 0.0 <= blend_value <= 1.0:
                raise ValueError(
                    f'{blend_name} must satisfy 0 <= blend <= 1.')
        normalized_levels = tuple(sorted(set(split_levels)))
        for level in normalized_levels:
            if level < 0 or level >= num_out_levels:
                raise ValueError(
                    f'split_levels contains invalid level {level}, '
                    f'expected 0 <= level < {num_out_levels}.')

        super(TUN3DLateSplitNeck, self).__init__(in_channels, out_channels)
        self.split_levels = normalized_levels
        self.layout_split_blend = layout_split_blend
        self.det_split_blend = det_split_blend
        self.split_kernel_size = split_kernel_size
        self.layout_refine_blocks = nn.ModuleDict()
        self.det_refine_blocks = nn.ModuleDict()

        for level in self.split_levels:
            level_name = str(level)
            self.layout_refine_blocks[level_name] = self._make_refine_block(
                out_channels, split_kernel_size)
            if self.det_split_blend > 0.0:
                self.det_refine_blocks[level_name] = self._make_refine_block(
                    out_channels, split_kernel_size)

    @staticmethod
    def _make_refine_block(out_channels: int,
                           kernel_size: int,
                           dimension: int = 3) -> nn.Module:
        return nn.Sequential(
            ME.MinkowskiConvolution(
                out_channels,
                out_channels,
                kernel_size=kernel_size,
                stride=1,
                dimension=dimension),
            ME.MinkowskiBatchNorm(out_channels),
            ME.MinkowskiReLU(inplace=True))

    @staticmethod
    def _blend_sparse_tensor(shared: SparseTensor, refined: SparseTensor,
                             blend: float) -> SparseTensor:
        if blend <= 0.0:
            return shared
        if blend >= 1.0:
            return refined
        return ME.SparseTensor(
            features=shared.features +
            blend * (refined.features - shared.features),
            coordinate_map_key=shared.coordinate_map_key,
            coordinate_manager=shared.coordinate_manager)

    def forward(self, x: List[SparseTensor]):
        shared_outs = super(TUN3DLateSplitNeck, self).forward(x)
        det_outs = list(shared_outs)
        layout_outs = list(shared_outs)

        for level in self.split_levels:
            level_name = str(level)
            shared_feature = shared_outs[level]
            layout_refined = self.layout_refine_blocks[level_name](
                shared_feature)
            layout_outs[level] = self._blend_sparse_tensor(
                shared_feature, layout_refined, self.layout_split_blend)
            if level_name in self.det_refine_blocks:
                det_refined = self.det_refine_blocks[level_name](shared_feature)
                det_outs[level] = self._blend_sparse_tensor(
                    shared_feature, det_refined, self.det_split_blend)

        return det_outs, layout_outs
