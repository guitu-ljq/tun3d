# v2.3 vs v2.9a 对照框架

更新时间：2026-04-27

## 注意

- 当前 `v2.9a` 是正式无 AMP 训练，结果来自 `work_dirs/tun3d_unposed_geovoxel_v2_9a_noamp`。
- 当前能找到的 `v2.3` 结果是 `smoke_recheck`，路径为 `work_dirs/tun3d_unposed_geovoxel_v2_3_smoke_recheck`。
- 此外，本地还保留了 `v2.3` 主线历史短跑目录：`work_dirs/geovoxel_quick_sweep/v2p3_dualpath_pctl_midblend`、`work_dirs/geovoxel_quick_sweep/v2p3_midblend_4epoch` 等；这些实验支撑了“v2.3 是此前主线最好候选”的判断。
- 因为两者的运行设置和验证规模不完全一致，下面首表只能作为“早期方向参考”，不能当最终公平结论。
- 真正公平结论需要后续补跑 `v2.3` 正式无 AMP 对照。

## 首轮验证快照（仅做方向参考）

| 指标 | v2.3 smoke epoch1 | v2.9a noamp epoch1 | 差值(v2.9a-v2.3) | 备注 |
|---|---:|---:|---:|---|
| ScanNet mAP@0.25 | 0.4187 | 0.4092 | -0.0095 | 接近 |
| ScanNet mAP@0.50 | 0.1810 | 0.1929 | +0.0119 | v2.9a 略高 |
| ScanNet layout F1 | 0.4416 | 0.4560 | +0.0144 | v2.9a 略高 |
| S3DIS mAP@0.25 | 0.1156 | 0.0882 | -0.0274 | v2.9a 偏低 |
| S3DIS mAP@0.50 | 0.0193 | 0.0105 | -0.0088 | v2.9a 偏低 |
| S3DIS layout F1 | 0.3187 | 0.2087 | -0.1100 | v2.9a 明显偏低 |

## 正式对照表（后续填写）

### v2.3 正式无 AMP

| epoch | ScanNet mAP@0.25 | ScanNet mAP@0.50 | ScanNet layout F1 | S3DIS mAP@0.25 | S3DIS mAP@0.50 | S3DIS layout F1 | 备注 |
|---|---:|---:|---:|---:|---:|---:|---|
| 1 | TBD | TBD | TBD | TBD | TBD | TBD | |
| 2 | TBD | TBD | TBD | TBD | TBD | TBD | |
| 3 | TBD | TBD | TBD | TBD | TBD | TBD | |
| 4 | TBD | TBD | TBD | TBD | TBD | TBD | |
| 6 | TBD | TBD | TBD | TBD | TBD | TBD | |

### v2.9a 正式无 AMP

| epoch | ScanNet mAP@0.25 | ScanNet mAP@0.50 | ScanNet layout F1 | S3DIS mAP@0.25 | S3DIS mAP@0.50 | S3DIS layout F1 | 备注 |
|---|---:|---:|---:|---:|---:|---:|---|
| 1 | 0.4092 | 0.1929 | 0.4560 | 0.0882 | 0.0105 | 0.2087 | 首轮 val，训练稳定，无 nan |
| 2 | TBD | TBD | TBD | TBD | TBD | TBD | |
| 3 | TBD | TBD | TBD | TBD | TBD | TBD | |
| 4 | TBD | TBD | TBD | TBD | TBD | TBD | |
| 6 | TBD | TBD | TBD | TBD | TBD | TBD | |

## 判定观察点

- `v2.3` 的历史主线地位，主要来自短跑与复验结论，而不是当前这一轮已经存在的“正式 no AMP 完整对照”。
- 如果 `epoch 2-3` 开始，`ScanNet mAP@0.50` 和 `ScanNet layout F1` 同时高于各自 `epoch 1`，说明 unified bottleneck 至少没有抑制联合任务优化。
- 如果 `ScanNet` 有提升但 `S3DIS` 持续显著偏低，说明这版可能更偏向修复场景内旁路泄漏，但跨域泛化还没被解决。
- 如果 `epoch 3-4` 仍看不到核心指标上升趋势，就要警惕这版只是“训练稳定但收益弱”。
- 如果必须等到 `epoch 6` 才能看出方向，那通常意味着增益非常弱，工程价值会打折扣。
